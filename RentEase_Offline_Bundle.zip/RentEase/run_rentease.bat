@echo off
echo Starting RentEase - Furniture & Appliance Rental Platform...

:: Start Backend
start cmd /k "cd server && node index.js"
echo Backend starting on http://localhost:5000...

:: Start Frontend
start cmd /k "cd client && npm run dev"
echo Frontend starting on http://localhost:5173...

echo.
echo All services are starting. Please wait a few seconds, then visit:
echo http://localhost:5173
echo.
pause
