import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { RotateCcw, Maximize2, Move } from 'lucide-react';

const Viewer360 = ({ imageUrl }) => {
  const [rotation, setRotation] = useState(0);
  const [isDragging, setIsDragging] = useState(false);
  const [startX, setStartX] = useState(0);

  const handleMouseDown = (e) => {
    setIsDragging(true);
    setStartX(e.clientX);
  };

  const handleMouseMove = (e) => {
    if (!isDragging) return;
    const diff = e.clientX - startX;
    setRotation((prev) => prev + diff * 0.5);
    setStartX(e.clientX);
  };

  const handleMouseUp = () => {
    setIsDragging(false);
  };

  return (
    <div className="relative group cursor-grab active:cursor-grabbing select-none overflow-hidden rounded-[60px] bg-white dark:bg-slate-900 shadow-2xl border-8 border-white dark:border-slate-800 aspect-square flex items-center justify-center transition-colors duration-500">
      <div className="absolute top-8 left-8 z-20 flex items-center space-x-2 bg-slate-900/80 dark:bg-slate-800/90 backdrop-blur-md text-white px-4 py-2 rounded-2xl text-xs font-black uppercase tracking-widest">
        <RotateCcw className="h-4 w-4 animate-spin-slow" />
        <span>360° Interactive View</span>
      </div>

      <motion.div
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        style={{ rotateY: rotation }}
        className="w-full h-full transform-style-3d transition-transform duration-100 ease-out"
      >
        <img 
          src={imageUrl} 
          alt="360 view" 
          className="w-full h-full object-cover pointer-events-none drop-shadow-[0_20px_50px_rgba(0,0,0,0.1)] dark:drop-shadow-none"
        />
      </motion.div>

      {/* Control Overlay */}
      <div className="absolute bottom-8 inset-x-8 z-20 flex justify-between items-center opacity-0 group-hover:opacity-100 transition-opacity">
        <div className="flex space-x-2">
          <button className="p-3 bg-white/90 dark:bg-slate-800/90 backdrop-blur rounded-xl text-slate-900 dark:text-white shadow-lg hover:bg-primary hover:text-white transition-all">
            <Move className="h-5 w-5" />
          </button>
          <button className="p-3 bg-white/90 dark:bg-slate-800/90 backdrop-blur rounded-xl text-slate-900 dark:text-white shadow-lg hover:bg-primary hover:text-white transition-all">
            <Maximize2 className="h-5 w-5" />
          </button>
        </div>
        <p className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-tighter">Drag horizontally to rotate</p>
      </div>

      {/* Reflection Effect */}
      <div className="absolute inset-0 bg-gradient-to-tr from-white/10 via-transparent to-white/5 pointer-events-none dark:from-white/5" />
    </div>
  );
};

export default Viewer360;
