import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Lock, Eye, FileText, CheckCircle2 } from 'lucide-react';

const Privacy = () => {
  return (
    <div className="bg-white dark:bg-slate-950 py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl font-black text-slate-900 dark:text-white mb-6"
          >
            Trust & <span className="text-primary">Privacy.</span>
          </motion.h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 font-medium">Your data and security are our top priorities.</p>
        </div>

        <div className="space-y-16">
          <section className="space-y-6">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-primary/10 p-3 rounded-xl text-primary">
                <ShieldCheck className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Data Protection</h2>
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-medium text-lg">
              At RentEase, we use industry-standard encryption to protect your personal information. 
              We never share your data with third parties for marketing purposes. All payment information 
              is handled by secure, PCI-compliant payment gateways.
            </p>
          </section>

          <section className="space-y-6">
            <div className="flex items-center space-x-4 mb-4">
              <div className="bg-primary/10 p-3 rounded-xl text-primary">
                <Eye className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Transparency</h2>
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-medium text-lg">
              We believe in full transparency. Our rental agreements are written in plain English, 
              free from hidden fees or confusing jargon. You'll always know exactly what you're paying 
              for and what your responsibilities are.
            </p>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {[
                "No hidden maintenance fees",
                "Clear deposit refund policy",
                "Detailed damage assessment",
                "Simple cancellation terms"
              ].map((item, idx) => (
                <li key={idx} className="flex items-center space-x-3 text-slate-900 dark:text-white font-bold">
                  <CheckCircle2 className="h-5 w-5 text-green-500" />
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className="bg-slate-50 dark:bg-slate-900/50 p-12 rounded-[40px] border border-slate-100 dark:border-slate-800">
            <div className="flex items-center space-x-4 mb-8">
              <div className="bg-primary/10 p-3 rounded-xl text-primary">
                <Lock className="h-6 w-6" />
              </div>
              <h2 className="text-3xl font-bold text-slate-900 dark:text-white">Security Audit</h2>
            </div>
            <p className="text-slate-600 dark:text-slate-400 leading-relaxed font-medium mb-8">
              Our platform undergoes regular security audits to ensure your experience is safe and secure. 
              We employ advanced fraud detection systems to monitor all transactions in real-time.
            </p>
            <div className="flex space-x-4">
              <div className="px-6 py-3 bg-white dark:bg-slate-900 rounded-xl shadow-sm dark:shadow-none border border-slate-100 dark:border-slate-800 flex items-center">
                <FileText className="h-5 w-5 mr-2 text-slate-400" />
                <span className="font-bold text-slate-900 dark:text-white text-sm italic">Audit Report 2026.pdf</span>
              </div>
            </div>
          </section>
        </div>
      </div>
    </div>
  );
};

export default Privacy;
