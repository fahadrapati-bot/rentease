import React, { useState, useEffect } from 'react';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { Package, Clock, Calendar, IndianRupee, Wrench } from 'lucide-react';

const Dashboard = () => {
  const { user } = useAuth();
  const [rentals, setRentals] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchRentals();
    }
  }, [user]);

  const fetchRentals = async () => {
    try {
      const res = await api.get(`/rentals/user/${user.id}`);
      setRentals(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleMaintenance = async (rentalId) => {
    const issue = prompt('Please describe the issue:');
    if (!issue) return;

    try {
      await api.post('/maintenance', { rental_id: rentalId, issue });
      alert('Maintenance request submitted!');
    } catch (err) {
      alert('Failed to submit request.');
    }
  };

  if (loading) return <div className="p-10 text-center text-slate-900 dark:text-white">Loading your rentals...</div>;

  return (
    <div className="bg-[#fcfcfd] dark:bg-slate-950 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="mb-12">
          <h1 className="text-4xl font-bold text-slate-900 dark:text-white">Welcome back, {user?.name}!</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-2">Manage your active rentals and maintenance requests.</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          <div className="lg:col-span-2 space-y-8">
            <h2 className="text-2xl font-bold text-slate-900 dark:text-white flex items-center">
              <Package className="mr-2 h-6 w-6 text-primary" /> Active Rentals
            </h2>
            
            {rentals.length === 0 ? (
              <div className="bg-white dark:bg-slate-900 p-12 rounded-3xl text-center border border-dashed border-slate-300 dark:border-slate-800">
                <p className="text-slate-400">You don't have any active rentals yet.</p>
              </div>
            ) : (
              rentals.map((r) => (
                <div key={r.id} className="bg-white dark:bg-slate-900 rounded-3xl p-6 shadow-sm dark:shadow-none border border-slate-100 dark:border-slate-800 flex flex-col md:flex-row gap-6">
                  <img src={r.image_url} alt={r.product_name} className="w-full md:w-40 h-40 object-cover rounded-2xl" />
                  <div className="flex-1 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h3 className="text-xl font-bold text-slate-900 dark:text-white">{r.product_name}</h3>
                        <span className="px-3 py-1 bg-green-100 text-green-600 rounded-full text-xs font-bold uppercase mt-2 inline-block">
                          {r.status}
                        </span>
                      </div>
                      <div className="text-right">
                        <span className="text-slate-400 text-xs block uppercase font-bold">Total Paid</span>
                        <div className="flex items-center text-xl font-black text-slate-900 dark:text-white">
                          <IndianRupee className="h-4 w-4" />
                          {r.total_price}
                        </div>
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-4 py-4 border-y border-slate-50 dark:border-slate-800">
                      <div className="flex items-center text-slate-600 dark:text-slate-400">
                        <Clock className="h-4 w-4 mr-2 text-primary" />
                        <span className="text-sm">{r.tenure_months} Months</span>
                      </div>
                      <div className="flex items-center text-slate-600 dark:text-slate-400">
                        <Calendar className="h-4 w-4 mr-2 text-primary" />
                        <span className="text-sm">Ends {r.end_date}</span>
                      </div>
                    </div>

                    <div className="flex space-x-3">
                      <button 
                        onClick={() => handleMaintenance(r.id)}
                        className="flex-1 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-200 py-3 rounded-xl font-bold hover:bg-slate-100 dark:hover:bg-slate-700 transition flex items-center justify-center border border-slate-200 dark:border-slate-700"
                      >
                        <Wrench className="h-4 w-4 mr-2" /> Maintenance
                      </button>
                      <button className="flex-1 bg-primary text-white py-3 rounded-xl font-bold hover:bg-primary-dark transition">
                        Extend Plan
                      </button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>

          <div className="space-y-8">
            <div className="bg-slate-900 dark:bg-slate-950 rounded-3xl p-8 text-white shadow-xl shadow-slate-200 dark:shadow-none">
              <h3 className="text-xl font-bold mb-6">Quick Stats</h3>
              <div className="space-y-6">
                <div>
                  <span className="text-slate-400 text-sm block">Total Active Rentals</span>
                  <span className="text-3xl font-black">{rentals.length}</span>
                </div>
                <div>
                  <span className="text-slate-400 text-sm block">Monthly Expenditure</span>
                  <div className="flex items-center text-3xl font-black text-primary">
                    <IndianRupee className="h-6 w-6" />
                    {rentals.reduce((acc, r) => acc + (r.total_price / r.tenure_months), 0).toFixed(0)}
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-white dark:bg-slate-900 rounded-3xl p-8 border border-slate-100 dark:border-slate-800 shadow-sm dark:shadow-none">
              <h3 className="text-xl font-bold text-slate-900 dark:text-white mb-4">Need Help?</h3>
              <p className="text-slate-500 dark:text-slate-400 text-sm mb-6">Our 24/7 support team is here to help you with relocation, maintenance, or returns.</p>
              <button className="w-full bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-slate-200 py-4 rounded-2xl font-bold border border-slate-200 dark:border-slate-700 hover:bg-slate-100 dark:hover:bg-slate-700 transition">
                Contact Support
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
