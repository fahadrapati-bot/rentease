import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Mail, Phone, Lock, ArrowRight, ShieldCheck, CheckCircle2, KeyRound } from 'lucide-react';
import { useNavigate, Link } from 'react-router-dom';
import api from '../api';

const ForgotPassword = () => {
  const navigate = useNavigate();
  const [step, setStep] = useState(1); // 1: Input, 2: OTP, 3: Reset
  const [identifier, setIdentifier] = useState('');
  const [code, setCode] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleRequestOTP = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.post('/auth/forgot-password', { identifier });
      setStep(2);
    } catch (err) {
      setError(err.response?.data?.error || 'Failed to send verification code');
    } finally {
      setLoading(false);
    }
  };

  const handleVerifyOTP = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.post('/auth/verify-otp', { identifier, code });
      setStep(3);
    } catch (err) {
      setError(err.response?.data?.error || 'Invalid or expired code');
    } finally {
      setLoading(false);
    }
  };

  const handleResetPassword = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    try {
      await api.post('/auth/reset-password', { identifier, code, newPassword });
      setStep(4); // Success
      setTimeout(() => navigate('/login'), 3000);
    } catch (err) {
      setError(err.response?.data?.error || 'Reset failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-50 dark:bg-slate-950 transition-colors duration-500">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="max-w-md w-full bg-white dark:bg-slate-900 p-12 rounded-[50px] shadow-2xl border border-slate-100 dark:border-slate-800"
      >
        <div className="text-center mb-10">
          <div className="bg-primary/10 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 text-primary">
            <KeyRound className="h-8 w-8" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-2">Secure Reset</h2>
          <p className="text-slate-500 dark:text-slate-400 font-medium">Protecting your RentEase account.</p>
        </div>

        <AnimatePresence mode="wait">
          {step === 1 && (
            <motion.form 
              key="step1"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleRequestOTP} 
              className="space-y-6"
            >
              <div className="relative">
                <Mail className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input 
                  type="text" 
                  required
                  placeholder="Email or Phone Number"
                  className="w-full pl-12 pr-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none focus:ring-2 focus:ring-primary font-bold text-slate-700 dark:text-white"
                  value={identifier}
                  onChange={(e) => setIdentifier(e.target.value)}
                />
              </div>
              {error && <p className="text-red-500 text-sm font-bold text-center">{error}</p>}
              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-slate-900 dark:bg-primary text-white py-4 rounded-2xl font-black hover:opacity-90 transition-all flex items-center justify-center space-x-2 shadow-xl shadow-primary/20"
              >
                <span>{loading ? 'Sending...' : 'Get Reset Code'}</span>
                {!loading && <ArrowRight className="h-5 w-5" />}
              </button>
            </motion.form>
          )}

          {step === 2 && (
            <motion.form 
              key="step2"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleVerifyOTP} 
              className="space-y-6"
            >
              <p className="text-sm text-slate-500 dark:text-slate-400 text-center mb-4">We've sent a 6-digit code to <b>{identifier}</b></p>
              <div className="relative">
                <ShieldCheck className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input 
                  type="text" 
                  required
                  placeholder="Enter 6-digit code"
                  className="w-full pl-12 pr-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none focus:ring-2 focus:ring-primary font-bold text-center tracking-[0.5em] text-slate-700 dark:text-white"
                  maxLength={6}
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                />
              </div>
              {error && <p className="text-red-500 text-sm font-bold text-center">{error}</p>}
              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-slate-900 dark:bg-primary text-white py-4 rounded-2xl font-black hover:opacity-90 transition-all shadow-xl"
              >
                {loading ? 'Verifying...' : 'Verify Code'}
              </button>
              <button 
                type="button" 
                onClick={() => setStep(1)}
                className="w-full text-slate-400 font-bold text-sm hover:text-primary transition-colors"
              >
                Change Email/Phone
              </button>
            </motion.form>
          )}

          {step === 3 && (
            <motion.form 
              key="step3"
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              onSubmit={handleResetPassword} 
              className="space-y-6"
            >
              <div className="relative">
                <Lock className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
                <input 
                  type="password" 
                  required
                  placeholder="New Password"
                  className="w-full pl-12 pr-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none focus:ring-2 focus:ring-primary font-bold text-slate-700 dark:text-white"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                />
              </div>
              {error && <p className="text-red-500 text-sm font-bold text-center">{error}</p>}
              <button 
                type="submit" 
                disabled={loading}
                className="w-full bg-slate-900 dark:bg-primary text-white py-4 rounded-2xl font-black hover:opacity-90 transition-all shadow-xl"
              >
                {loading ? 'Resetting...' : 'Change Password'}
              </button>
            </motion.form>
          )}

          {step === 4 && (
            <motion.div 
              key="step4"
              initial={{ scale: 0.9, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-center"
            >
              <div className="bg-green-100 dark:bg-green-900/30 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-6 text-green-500">
                <CheckCircle2 className="h-10 w-10" />
              </div>
              <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2">Success!</h3>
              <p className="text-slate-500 dark:text-slate-400 font-medium mb-6">Your password has been updated. Redirecting to login...</p>
            </motion.div>
          )}
        </AnimatePresence>

        <div className="mt-10 pt-10 border-t border-slate-50 dark:border-slate-800 text-center">
          <Link to="/login" className="text-slate-400 hover:text-primary font-bold transition-all text-sm uppercase tracking-widest">
            Back to Login
          </Link>
        </div>
      </motion.div>
    </div>
  );
};

export default ForgotPassword;
