import React, { useState, useEffect } from 'react';
import api from '../api';
import { useAuth } from '../context/AuthContext';
import { motion, AnimatePresence } from 'framer-motion';
import { Heart, Trash2, IndianRupee, ShoppingBag } from 'lucide-react';
import { Link } from 'react-router-dom';

const Wishlist = () => {
  const { user } = useAuth();
  const [favorites, setFavorites] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) fetchWishlist();
  }, [user]);

  const fetchWishlist = async () => {
    try {
      const res = await api.get(`/favorites/user/${user.id}`);
      setFavorites(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const removeFavorite = async (productId) => {
    try {
      await api.delete(`/favorites/${user.id}/${productId}`);
      setFavorites(favorites.filter(f => f.id !== productId));
    } catch (err) {
      alert('Failed to remove item');
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white dark:bg-slate-950">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-primary"></div>
    </div>
  );

  return (
    <div className="min-h-screen max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 bg-[#fcfcfd] dark:bg-slate-950 transition-colors duration-500">
      <div className="flex items-center space-x-4 mb-16">
        <div className="bg-red-100 dark:bg-red-900/20 p-4 rounded-3xl text-red-500">
          <Heart className="h-8 w-8 fill-current" />
        </div>
        <h1 className="text-5xl font-black text-slate-900 dark:text-white">Your <span className="text-red-500">Wishlist.</span></h1>
      </div>

      {favorites.length === 0 ? (
        <div className="bg-white dark:bg-slate-900 rounded-[60px] p-20 text-center border-4 border-dashed border-slate-100 dark:border-slate-800">
          <ShoppingBag className="h-20 w-20 text-slate-200 dark:text-slate-700 mx-auto mb-8" />
          <p className="text-2xl font-black text-slate-300 dark:text-slate-600 mb-8">Your wishlist is currently empty.</p>
          <Link to="/catalog" className="bg-primary text-white px-10 py-5 rounded-2xl font-black text-xl shadow-xl shadow-primary/20 hover:scale-105 transition-all inline-block">
            Browse Catalog
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          <AnimatePresence>
            {favorites.map((p) => (
              <motion.div
                key={p.id}
                layout
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.9 }}
                className="bg-white dark:bg-slate-900 rounded-[40px] overflow-hidden shadow-xl border border-slate-100 dark:border-slate-800 relative group"
              >
                <img src={p.image_url} className="h-64 w-full object-cover" alt={p.name} />
                <button 
                  onClick={() => removeFavorite(p.id)}
                  className="absolute top-6 right-6 p-4 bg-white/90 dark:bg-slate-800/90 backdrop-blur rounded-2xl text-slate-400 hover:text-red-500 shadow-xl transition-all"
                >
                  <Trash2 className="h-6 w-6" />
                </button>
                <div className="p-8">
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-2 group-hover:text-primary transition-colors">{p.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm mb-6 line-clamp-1">{p.description}</p>
                  <div className="flex items-center justify-between">
                    <div>
                      <span className="text-[10px] font-black text-slate-400 dark:text-slate-500 uppercase tracking-widest block mb-1">Rent / Mo</span>
                      <div className="flex items-center text-2xl font-black text-slate-900 dark:text-white">
                        <IndianRupee className="h-5 w-5 text-primary" />
                        {p.monthly_rent}
                      </div>
                    </div>
                    <Link to={`/product/${p.id}`} className="bg-slate-900 dark:bg-primary text-white px-6 py-3 rounded-xl font-bold hover:bg-primary dark:hover:opacity-90 transition-all">
                      View Item
                    </Link>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>
        </div>
      )}
    </div>
  );
};

export default Wishlist;
