import React from 'react';
import { motion } from 'framer-motion';
import { Truck, MapPin, PackageCheck, Clock, ShieldCheck, ArrowRight } from 'lucide-react';

const Relocation = () => {
  return (
    <div className="bg-[#fcfcfd] dark:bg-slate-950 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-24">
          <motion.div
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-6 py-2 rounded-full mb-8 font-black text-sm uppercase tracking-widest"
          >
            <Truck className="h-4 w-4" />
            <span>Stress-Free Moving</span>
          </motion.div>
          <h1 className="text-7xl font-black text-slate-900 dark:text-white mb-8 leading-tight">
            Move Cities, <br/><span className="text-primary">Not Furniture.</span>
          </h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 max-w-3xl mx-auto font-medium leading-relaxed">
            Our exclusive Relocation Support ensures your rented products move with you, 
            or are swapped for fresh ones at your new destination. Zero hassle, zero heavy lifting.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 mb-32">
          {[
            {
              icon: <MapPin className="h-10 w-10" />,
              title: "Multi-City Support",
              desc: "Moving from Bengaluru to Mumbai? We handle the logistics and ensure your setup is ready before you arrive."
            },
            {
              icon: <PackageCheck className="h-10 w-10" />,
              title: "Free Uninstallation",
              desc: "Our professional team will dismantle and pack all rented items securely at no extra cost to you."
            },
            {
              icon: <Clock className="h-10 w-10" />,
              title: "48-Hour Setup",
              desc: "We guarantee your new home will be fully furnished within 48 hours of your move-in date."
            }
          ].map((item, idx) => (
            <motion.div
              key={idx}
              whileHover={{ y: -20, rotateX: 5 }}
              className="bg-white dark:bg-slate-900 p-12 rounded-[50px] shadow-xl dark:shadow-none border border-slate-100 dark:border-slate-800 perspective-1000 transform-style-3d group"
            >
              <div className="bg-primary/10 p-5 rounded-3xl text-primary w-fit mb-8 group-hover:bg-primary group-hover:text-white transition-all">
                {item.icon}
              </div>
              <h3 className="text-3xl font-black text-slate-900 dark:text-white mb-6">{item.title}</h3>
              <p className="text-slate-500 dark:text-slate-400 font-medium leading-relaxed">{item.desc}</p>
            </motion.div>
          ))}
        </div>

        <div className="bg-slate-900 dark:bg-slate-950 rounded-[60px] p-16 text-white relative overflow-hidden">
          <div className="relative z-10 grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-5xl font-black mb-8 leading-tight">Planning a move? <br/>Let us help.</h2>
              <p className="text-xl text-slate-400 mb-10 leading-relaxed font-medium">
                Notify us at least 14 days before your move, and we'll handle everything from uninstallation to delivery at your new address.
              </p>
              <button className="bg-primary text-white px-10 py-5 rounded-2xl font-black text-xl hover:bg-primary-dark transition-all flex items-center group shadow-2xl shadow-primary/20">
                Book Relocation Support <ArrowRight className="ml-2 h-6 w-6 group-hover:translate-x-2 transition-transform" />
              </button>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1586023492125-27b2c045efd7?w=800&q=80" 
                className="rounded-[40px] shadow-2xl rotate-3 group-hover:rotate-0 transition-transform duration-700"
                alt="Moving"
              />
              <div className="absolute -top-10 -right-10 bg-white dark:bg-slate-900 p-6 rounded-3xl shadow-2xl dark:shadow-none text-slate-900 dark:text-white hidden lg:block border border-slate-100 dark:border-slate-800">
                <ShieldCheck className="h-10 w-10 text-green-500 mb-2" />
                <p className="font-black text-lg">Insured Moving</p>
                <p className="text-slate-500 dark:text-slate-400 text-sm">Every item is covered</p>
              </div>
            </div>
          </div>
          <div className="absolute top-0 right-0 w-96 h-96 bg-primary/10 rounded-full blur-[120px] -mr-48 -mt-48" />
        </div>
      </div>
    </div>
  );
};

export default Relocation;
