import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Upload, Sofa, Send, CheckCircle2, ChevronRight, Info } from 'lucide-react';

const CustomRequest = () => {
  const [file, setFile] = useState(null);
  const [submitted, setSubmitted] = useState(false);
  const [formData, setForm] = useState({ name: '', type: 'Sofa', description: '' });

  const handleUpload = (e) => {
    const uploadedFile = e.target.files[0];
    if (uploadedFile) {
      setFile(uploadedFile);
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setSubmitted(true);
  };

  if (submitted) return (
    <div className="min-h-[80vh] flex items-center justify-center p-4">
      <motion.div 
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        className="max-w-md w-full bg-white dark:bg-slate-900 p-12 rounded-[50px] shadow-2xl text-center border border-slate-100 dark:border-slate-800"
      >
        <div className="bg-green-100 dark:bg-green-900/30 w-24 h-24 rounded-full flex items-center justify-center mx-auto mb-8 text-green-500">
          <CheckCircle2 className="h-12 w-12" />
        </div>
        <h2 className="text-4xl font-black text-slate-900 dark:text-white mb-4 tracking-tight">Request Received!</h2>
        <p className="text-slate-500 dark:text-slate-400 font-medium mb-10 leading-relaxed">
          Our design team is reviewing your requirement for a <b>{formData.type}</b>. We will get back to you within 24 hours.
        </p>
        <button 
          onClick={() => setSubmitted(false)}
          className="bg-slate-900 dark:bg-primary text-white px-8 py-4 rounded-2xl font-black transition-all hover:scale-105 active:scale-95"
        >
          Make Another Request
        </button>
      </motion.div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
        <div>
          <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-8 font-bold text-sm">
            <Info className="h-4 w-4" />
            <span>Custom Furniture Finder</span>
          </div>
          <h1 className="text-7xl font-black text-slate-900 dark:text-white leading-tight mb-8 tracking-tighter">
            Can't find what you're <span className="text-primary">looking for?</span>
          </h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 font-medium mb-12 leading-relaxed max-w-xl">
            Upload an image or describe the type of furniture you need. We'll source it specifically for your rental plan at no extra cost.
          </p>

          <div className="space-y-6">
            <div className="flex items-center space-x-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm transition-all hover:shadow-md">
              <div className="bg-orange-100 dark:bg-orange-900/30 p-3 rounded-2xl text-orange-600">
                <Sofa />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Tell us the Type</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">Specify if it's a sofa, bed, or office desk.</p>
              </div>
            </div>
            <div className="flex items-center space-x-4 bg-white dark:bg-slate-900 p-6 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm transition-all hover:shadow-md">
              <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-2xl text-blue-600">
                <Upload />
              </div>
              <div>
                <h4 className="font-bold text-slate-900 dark:text-white">Upload Reference</h4>
                <p className="text-sm text-slate-500 dark:text-slate-400">Found a design on Pinterest? Send us the image!</p>
              </div>
            </div>
          </div>
        </div>

        <motion.div 
          initial={{ y: 20, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          className="bg-white dark:bg-slate-900 p-12 rounded-[60px] shadow-2xl border border-slate-100 dark:border-slate-800"
        >
          <form onSubmit={handleSubmit} className="space-y-8">
            <div>
              <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-3 ml-2">Furniture Type</label>
              <select 
                value={formData.type}
                onChange={(e) => setForm({...formData, type: e.target.value})}
                className="w-full px-6 py-5 rounded-3xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-primary outline-none transition-all font-bold text-slate-700 dark:text-white appearance-none"
              >
                <option>Sofa & Living</option>
                <option>Bed & Bedroom</option>
                <option>Dining & Kitchen</option>
                <option>Office & Study</option>
                <option>Outdoor & Balcony</option>
              </select>
            </div>

            <div>
              <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-3 ml-2">Description</label>
              <textarea 
                required
                placeholder="E.g. I need a 3-seater navy blue velvet sofa with golden legs..."
                className="w-full px-6 py-5 rounded-3xl bg-slate-50 dark:bg-slate-800 border-none focus:ring-2 focus:ring-primary outline-none transition-all font-bold text-slate-700 dark:text-white min-h-[150px] resize-none"
                value={formData.description}
                onChange={(e) => setForm({...formData, description: e.target.value})}
              />
            </div>

            <div>
              <label className="block text-xs font-black uppercase tracking-widest text-slate-400 mb-3 ml-2">Upload File (Optional)</label>
              <div className="relative group">
                <input 
                  type="file" 
                  onChange={handleUpload}
                  className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                />
                <div className="w-full px-6 py-10 rounded-3xl border-2 border-dashed border-slate-200 dark:border-slate-700 flex flex-col items-center justify-center space-y-4 group-hover:border-primary transition-colors">
                  <div className="bg-slate-50 dark:bg-slate-800 p-4 rounded-2xl text-slate-400 group-hover:text-primary transition-colors">
                    <Upload className="h-8 w-8" />
                  </div>
                  <span className="font-bold text-slate-500 dark:text-slate-400">
                    {file ? file.name : "Click or drag image here"}
                  </span>
                </div>
              </div>
            </div>

            <button 
              type="submit"
              className="w-full bg-slate-900 dark:bg-primary text-white py-6 rounded-3xl font-black text-xl hover:opacity-90 transition-all shadow-xl shadow-primary/20 flex items-center justify-center space-x-2"
            >
              <span>Submit Request</span>
              <Send className="h-5 w-5" />
            </button>
          </form>
        </motion.div>
      </div>
    </div>
  );
};

export default CustomRequest;
