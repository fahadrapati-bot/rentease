import React, { useState, useEffect } from 'react';
import api from '../api';
import { Plus, Edit, Trash, Package, Activity, DollarSign } from 'lucide-react';

const AdminDashboard = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [formData, setFormData] = useState({
    name: '', category: 'Furniture', sub_category: '', description: '',
    monthly_rent: '', security_deposit: '', stock: '', image_url: ''
  });

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await api.get('/products');
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleAddProduct = async (e) => {
    e.preventDefault();
    try {
      await api.post('/products', formData);
      alert('Product added!');
      setShowModal(false);
      fetchProducts();
    } catch (err) {
      alert('Failed to add product');
    }
  };

  if (loading) return <div className="p-10 text-center text-slate-900 dark:text-white">Loading admin panel...</div>;

  return (
    <div className="bg-[#fcfcfd] dark:bg-slate-950 min-h-screen">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex justify-between items-center mb-10">
          <h1 className="text-4xl font-black text-slate-900 dark:text-white">Admin Console</h1>
          <button 
            onClick={() => setShowModal(true)}
            className="bg-primary text-white px-6 py-3 rounded-xl font-bold flex items-center shadow-lg shadow-primary/20 hover:bg-primary-dark transition"
          >
            <Plus className="mr-2 h-5 w-5" /> Add New Product
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm dark:shadow-none">
            <div className="flex items-center justify-between mb-4">
              <Package className="h-8 w-8 text-primary" />
              <span className="text-slate-400 dark:text-slate-500 text-sm font-bold uppercase">Inventory</span>
            </div>
            <span className="text-4xl font-black text-slate-900 dark:text-white">{products.length}</span>
            <p className="text-slate-500 dark:text-slate-400 mt-2 text-sm">Total products listed</p>
          </div>
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm dark:shadow-none">
            <div className="flex items-center justify-between mb-4">
              <Activity className="h-8 w-8 text-green-500" />
              <span className="text-slate-400 dark:text-slate-500 text-sm font-bold uppercase">Active Rentals</span>
            </div>
            <span className="text-4xl font-black text-slate-900 dark:text-white">12</span>
            <p className="text-slate-500 dark:text-slate-400 mt-2 text-sm">Products currently on rent</p>
          </div>
          <div className="bg-white dark:bg-slate-900 p-8 rounded-3xl border border-slate-100 dark:border-slate-800 shadow-sm dark:shadow-none">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="h-8 w-8 text-orange-500" />
              <span className="text-slate-400 dark:text-slate-500 text-sm font-bold uppercase">Revenue</span>
            </div>
            <span className="text-4xl font-black text-slate-900 dark:text-white">₹45.2k</span>
            <p className="text-slate-500 dark:text-slate-400 mt-2 text-sm">Monthly recurring revenue</p>
          </div>
        </div>

        <div className="bg-white dark:bg-slate-900 rounded-[40px] overflow-hidden border border-slate-100 dark:border-slate-800 shadow-sm dark:shadow-none">
          <table className="w-full text-left">
            <thead className="bg-slate-50 dark:bg-slate-800 border-b border-slate-100 dark:border-slate-700">
              <tr>
                <th className="px-8 py-6 text-sm font-bold text-slate-400 dark:text-slate-500 uppercase">Product</th>
                <th className="px-8 py-6 text-sm font-bold text-slate-400 dark:text-slate-500 uppercase">Category</th>
                <th className="px-8 py-6 text-sm font-bold text-slate-400 dark:text-slate-500 uppercase">Monthly Rent</th>
                <th className="px-8 py-6 text-sm font-bold text-slate-400 dark:text-slate-500 uppercase">Stock</th>
                <th className="px-8 py-6 text-sm font-bold text-slate-400 dark:text-slate-500 uppercase text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50 dark:divide-slate-800">
              {products.map((p) => (
                <tr key={p.id} className="hover:bg-slate-50/50 dark:hover:bg-slate-800/50 transition-colors">
                  <td className="px-8 py-6 flex items-center space-x-4">
                    <img src={p.image_url} alt="" className="w-12 h-12 rounded-xl object-cover" />
                    <span className="font-bold text-slate-900 dark:text-white">{p.name}</span>
                  </td>
                  <td className="px-8 py-6">
                    <span className="px-3 py-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 rounded-full text-xs font-bold">{p.category}</span>
                  </td>
                  <td className="px-8 py-6 font-bold text-slate-900 dark:text-white">₹{p.monthly_rent}</td>
                  <td className="px-8 py-6 text-slate-500 dark:text-slate-400">{p.stock} units</td>
                  <td className="px-8 py-6 text-right">
                    <button className="p-2 text-slate-400 hover:text-primary transition mr-2"><Edit className="h-5 w-5" /></button>
                    <button className="p-2 text-slate-400 hover:text-red-500 transition"><Trash className="h-5 w-5" /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {showModal && (
          <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[100] flex items-center justify-center p-4">
            <div className="bg-white dark:bg-slate-900 w-full max-w-2xl rounded-[40px] p-10 shadow-2xl dark:shadow-none">
              <h2 className="text-3xl font-black text-slate-900 dark:text-white mb-8">Add New Product</h2>
              <form onSubmit={handleAddProduct} className="grid grid-cols-2 gap-6">
                <div className="col-span-2 space-y-2">
                  <label className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase ml-2">Product Name</label>
                  <input 
                    type="text" required
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary"
                    value={formData.name}
                    onChange={(e) => setFormData({...formData, name: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase ml-2">Category</label>
                  <select 
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary"
                    value={formData.category}
                    onChange={(e) => setFormData({...formData, category: e.target.value})}
                  >
                    <option value="Furniture" className="bg-white dark:bg-slate-900">Furniture</option>
                    <option value="Appliances" className="bg-white dark:bg-slate-900">Appliances</option>
                  </select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase ml-2">Stock</label>
                  <input 
                    type="number" required
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary"
                    value={formData.stock}
                    onChange={(e) => setFormData({...formData, stock: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase ml-2">Monthly Rent</label>
                  <input 
                    type="number" required
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary"
                    value={formData.monthly_rent}
                    onChange={(e) => setFormData({...formData, monthly_rent: e.target.value})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase ml-2">Security Deposit</label>
                  <input 
                    type="number" required
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary"
                    value={formData.security_deposit}
                    onChange={(e) => setFormData({...formData, security_deposit: e.target.value})}
                  />
                </div>
                <div className="col-span-2 space-y-2">
                  <label className="text-sm font-bold text-slate-400 dark:text-slate-500 uppercase ml-2">Image URL</label>
                  <input 
                    type="text" required
                    className="w-full px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-900 dark:text-white outline-none focus:ring-2 focus:ring-primary"
                    value={formData.image_url}
                    onChange={(e) => setFormData({...formData, image_url: e.target.value})}
                  />
                </div>
                <div className="col-span-2 flex space-x-4 mt-4">
                  <button 
                    type="submit"
                    className="flex-1 bg-primary text-white py-4 rounded-2xl font-bold hover:bg-primary-dark transition shadow-lg shadow-primary/20"
                  >
                    Save Product
                  </button>
                  <button 
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="flex-1 bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 py-4 rounded-2xl font-bold hover:bg-slate-200 dark:hover:bg-slate-700 transition"
                  >
                    Cancel
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminDashboard;
