import React from 'react';
import { motion } from 'framer-motion';
import { HelpCircle, ChevronDown, MessageCircle } from 'lucide-react';

const faqData = [
  {
    question: "What items can I rent from RentEase?",
    answer: "You can rent a wide variety of furniture (beds, sofas, tables, office chairs) and appliances (fridges, washing machines, TVs, microwaves). We focus on high-quality, premium products to ensure the best living experience."
  },
  {
    question: "How long can I rent a product for?",
    answer: "We offer flexible tenure plans starting from 3 months up to 24 months. The longer your tenure, the lower your monthly rent will be."
  },
  {
    question: "Is there a security deposit?",
    answer: "Yes, there is a fully refundable security deposit for each item. This deposit is returned to you within 7 working days after the product is picked up and inspected."
  },
  {
    question: "What happens if I damage the product?",
    answer: "We understand minor wear and tear happens. For major damages, a repair cost will be deducted from your security deposit. We also offer 'Damage Protection' plans for peace of mind."
  },
  {
    question: "Can I upgrade or swap items during my tenure?",
    answer: "Absolutely! After 6 months of your current tenure, you can request an upgrade or a swap for a different model. Service charges may apply."
  }
];

const FAQ = () => {
  return (
    <div className="bg-[#fcfcfd] dark:bg-slate-950 py-24">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <h1 className="text-6xl font-black text-slate-900 dark:text-white mb-6">Common <span className="text-primary">Questions.</span></h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 font-medium">Everything you need to know about renting with RentEase.</p>
        </div>

        <div className="space-y-6">
          {faqData.map((faq, idx) => (
            <motion.div 
              key={idx}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: idx * 0.1 }}
              className="bg-white dark:bg-slate-900 rounded-[30px] p-8 shadow-sm dark:shadow-none border border-slate-100 dark:border-slate-800 hover:shadow-xl dark:hover:shadow-none transition-all group cursor-pointer"
            >
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-bold text-slate-900 dark:text-white group-hover:text-primary transition-colors">{faq.question}</h3>
                <ChevronDown className="h-6 w-6 text-slate-400 group-hover:rotate-180 transition-transform" />
              </div>
              <p className="mt-4 text-slate-500 dark:text-slate-400 leading-relaxed font-medium hidden group-hover:block transition-all">
                {faq.answer}
              </p>
            </motion.div>
          ))}
        </div>

        <div className="mt-20 bg-primary/5 dark:bg-primary/10 rounded-[40px] p-12 text-center border-2 border-dashed border-primary/20 dark:border-primary/30">
          <MessageCircle className="h-12 w-12 text-primary mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-slate-900 dark:text-white mb-4">Still have questions?</h2>
          <p className="text-slate-500 dark:text-slate-400 mb-8 font-medium">Can't find the answer you're looking for? Please chat with our friendly team.</p>
          <button className="bg-primary text-white px-8 py-4 rounded-2xl font-bold shadow-lg shadow-primary/20 hover:bg-primary-dark transition-all">
            Start Live Chat
          </button>
        </div>
      </div>
    </div>
  );
};

export default FAQ;
