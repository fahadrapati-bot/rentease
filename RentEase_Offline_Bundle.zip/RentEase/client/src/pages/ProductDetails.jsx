import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../api';
import { motion } from 'framer-motion';
import { IndianRupee, ShieldCheck, Truck, RotateCcw, Calendar, Star, Info, ChevronRight, Share2, Heart, Download } from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import Viewer360 from '../components/Viewer360';

const ProductDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [tenure, setTenure] = useState(3);
  const [deliveryDate, setDeliveryDate] = useState('');
  const [viewMode, setViewMode] = useState('gallery'); // 'gallery' or '360'

  useEffect(() => {
    fetchProduct();
    window.scrollTo(0, 0);
  }, [id]);

  const fetchProduct = async () => {
    try {
      const res = await api.get(`/products/${id}`);
      setProduct(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async () => {
    try {
      const response = await fetch(product.image_url);
      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `${product.name.replace(/\s+/g, '_').toLowerCase()}.jpg`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Download failed', err);
    }
  };

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: `Rent ${product.name} on RentEase`,
        text: product.description,
        url: window.location.href,
      }).catch(console.error);
    } else {
      navigator.clipboard.writeText(window.location.href);
      alert('Link copied to clipboard!');
    }
  };

  const handleCheckout = async () => {
    if (!user) {
      navigate('/login');
      return;
    }

    if (!deliveryDate) {
      alert('Please select a delivery date');
      return;
    }

    const startDate = new Date().toISOString().split('T')[0];
    const endDate = new Date(new Date().setMonth(new Date().getMonth() + tenure)).toISOString().split('T')[0];
    const totalPrice = (product.monthly_rent * tenure) + product.security_deposit;

    try {
      await api.post('/rentals', {
        user_id: user.id,
        product_id: product.id,
        tenure_months: tenure,
        start_date: startDate,
        end_date: endDate,
        delivery_date: deliveryDate,
        total_price: totalPrice
      });
      alert('Rental successful!');
      navigate('/dashboard');
    } catch (err) {
      alert('Rental failed. Please try again.');
    }
  };

  const handleWishlist = async () => {
    if (!user) {
      navigate('/login');
      return;
    }
    try {
      await api.post('/favorites', { user_id: user.id, product_id: product.id });
      alert('Added to wishlist!');
    } catch (err) {
      alert(err.response?.data?.error || 'Failed to add to wishlist');
    }
  };

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white dark:bg-slate-950">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-primary"></div>
    </div>
  );

  if (!product) return <div className="p-20 text-center font-black text-3xl text-slate-300">Product not found.</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 bg-[#fcfcfd] dark:bg-slate-950 transition-colors duration-500">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-24 items-start">
        {/* Visual Showcase */}
        <div className="space-y-8 sticky top-32">
          <div className="flex justify-center space-x-4 mb-4">
            <button 
              onClick={() => setViewMode('gallery')}
              className={`px-6 py-2 rounded-xl font-bold transition-all ${viewMode === 'gallery' ? 'bg-primary text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-slate-400 dark:text-slate-500 border border-slate-100 dark:border-slate-700'}`}
            >
              Gallery
            </button>
            <button 
              onClick={() => setViewMode('360')}
              className={`px-6 py-2 rounded-xl font-bold transition-all ${viewMode === '360' ? 'bg-primary text-white shadow-lg' : 'bg-white dark:bg-slate-800 text-slate-400 dark:text-slate-500 border border-slate-100 dark:border-slate-700'}`}
            >
              360° View
            </button>
          </div>

          {viewMode === '360' ? (
            <Viewer360 imageUrl={product.image_url} />
          ) : (
            <motion.div 
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              className="rounded-[60px] overflow-hidden shadow-[0_50px_100px_-20px_rgba(0,0,0,0.15)] aspect-square border-8 border-white dark:border-slate-800 group relative"
            >
              <img 
                src={product.image_url} 
                alt={product.name} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-1000" 
              />
              <div className="absolute top-8 right-8 flex flex-col space-y-4">
                <button 
                  onClick={handleWishlist}
                  className="p-4 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-2xl shadow-xl text-slate-900 dark:text-white hover:text-red-500 transition-colors"
                >
                  <Heart className="h-6 w-6" />
                </button>
                <button 
                  onClick={handleShare}
                  className="p-4 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-2xl shadow-xl text-slate-900 dark:text-white hover:text-primary transition-colors"
                >
                  <Share2 className="h-6 w-6" />
                </button>
                <button 
                  onClick={handleDownload}
                  className="p-4 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md rounded-2xl shadow-xl text-slate-900 dark:text-white hover:text-green-500 transition-colors"
                >
                  <Download className="h-6 w-6" />
                </button>
              </div>
            </motion.div>
          )}
          
          <div className="grid grid-cols-3 gap-6">
            {[1,2,3].map(i => (
              <div key={i} className="aspect-square rounded-3xl overflow-hidden border-4 border-white dark:border-slate-800 shadow-lg cursor-pointer hover:border-primary transition-colors">
                <img src={product.image_url} className="w-full h-full object-cover opacity-50 hover:opacity-100 transition-opacity" alt="" />
              </div>
            ))}
          </div>

          <div className="bg-slate-900 dark:bg-slate-800 rounded-[40px] p-10 text-white relative overflow-hidden">
            <div className="relative z-10 flex items-center justify-between">
              <div>
                <p className="text-primary font-black text-sm uppercase tracking-widest mb-2">Exclusive Offer</p>
                <h4 className="text-2xl font-bold">First month at 50% off</h4>
                <p className="text-slate-400 mt-2">Use code RENT50 at checkout</p>
              </div>
              <div className="h-20 w-20 bg-primary/20 rounded-3xl flex items-center justify-center rotate-12">
                <Star className="h-10 w-10 text-primary fill-current" />
              </div>
            </div>
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[80px] -mr-32 -mt-32" />
          </div>
        </div>

        {/* Configuration Section */}
        <div className="space-y-12">
          <div>
            <div className="flex items-center space-x-2 text-primary font-black text-sm uppercase tracking-[0.2em] mb-4">
              <span>{product.category}</span>
              <ChevronRight className="h-4 w-4" />
              <span>{product.sub_category || 'Premium'}</span>
            </div>
            <h1 className="text-6xl font-black text-slate-900 dark:text-white leading-tight mb-6">{product.name}</h1>
            
            <div className="flex items-center space-x-6 mb-8">
              <div className="flex text-orange-400">
                {[1,2,3,4,5].map(i => <Star key={i} className="h-5 w-5 fill-current" />)}
              </div>
              <span className="text-slate-400 font-bold border-l pl-6 border-slate-200 dark:border-slate-800">124 Verified Reviews</span>
            </div>
            
            <p className="text-xl text-slate-500 dark:text-slate-400 leading-relaxed font-medium">
              {product.description} Experience ultimate comfort and style with our handpicked premium selection. Built to last and designed to impress.
            </p>
          </div>

          <div className="bg-white dark:bg-slate-900 rounded-[40px] p-10 shadow-xl border border-slate-100 dark:border-slate-800 grid grid-cols-2 gap-10">
            <div>
              <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest block mb-2">Monthly Subscription</span>
              <div className="flex items-center text-5xl font-black text-slate-900 dark:text-white">
                <IndianRupee className="h-8 w-8 text-primary" />
                {product.monthly_rent}
              </div>
            </div>
            <div>
              <span className="text-slate-400 dark:text-slate-500 text-xs font-black uppercase tracking-widest block mb-2">Refundable Deposit</span>
              <div className="flex items-center text-5xl font-black text-slate-400 dark:text-slate-500">
                <IndianRupee className="h-8 w-8" />
                {product.security_deposit}
              </div>
            </div>
          </div>

          <div className="space-y-6">
            <div className="flex items-center justify-between">
              <h3 className="font-black text-slate-900 dark:text-white text-xl">Select Your Tenure</h3>
              <span className="text-primary text-sm font-bold flex items-center bg-primary/10 px-3 py-1 rounded-lg">
                <Info className="h-4 w-4 mr-1" /> Best Value: 12 Months
              </span>
            </div>
            <div className="grid grid-cols-4 gap-4">
              {[3, 6, 12, 24].map((m) => (
                <button
                  key={m}
                  onClick={() => setTenure(m)}
                  className={`py-5 rounded-3xl font-black transition-all text-lg ${
                    tenure === m 
                    ? 'bg-primary text-white shadow-2xl shadow-primary/40 scale-105' 
                    : 'bg-white dark:bg-slate-800 text-slate-400 dark:text-slate-500 border-2 border-slate-100 dark:border-slate-700 hover:border-primary hover:text-primary'
                  }`}
                >
                  {m}m
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-6">
            <h3 className="font-black text-slate-900 dark:text-white text-xl">Preferred Delivery</h3>
            <div className="relative group">
              <Calendar className="absolute left-6 top-1/2 -translate-y-1/2 h-6 w-6 text-slate-400 group-focus-within:text-primary transition-colors" />
              <input 
                type="date" 
                className="w-full pl-16 pr-8 py-5 rounded-[25px] border-2 border-slate-100 dark:border-slate-700 outline-none focus:border-primary focus:ring-4 focus:ring-primary/10 transition-all font-bold text-slate-700 dark:text-slate-200 text-lg bg-white dark:bg-slate-800"
                value={deliveryDate}
                onChange={(e) => setDeliveryDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
              />
            </div>
          </div>

          <div className="flex flex-col sm:flex-row gap-6 pt-6">
            <button 
              onClick={handleCheckout}
              className="flex-[2] bg-slate-900 dark:bg-primary text-white py-6 rounded-[30px] font-black text-2xl hover:opacity-90 transition-all shadow-[0_20px_50px_-10px_rgba(0,0,0,0.3)] dark:shadow-none hover:shadow-primary/30 active:scale-95 flex items-center justify-center group"
            >
              Secure Checkout <ChevronRight className="ml-2 h-6 w-6 group-hover:translate-x-2 transition-transform" />
            </button>
            <button 
              onClick={handleWishlist}
              className="flex-1 bg-white dark:bg-slate-800 text-slate-900 dark:text-white py-6 rounded-[30px] font-black text-lg border-2 border-slate-100 dark:border-slate-700 hover:bg-slate-50 dark:hover:bg-slate-700 transition-all flex items-center justify-center"
            >
              Add to Wishlist
            </button>
          </div>

          <div className="grid grid-cols-3 gap-6">
            {[
              { icon: <Truck />, text: 'Free Setup' },
              { icon: <ShieldCheck />, text: '7-Day Return' },
              { icon: <RotateCcw />, text: 'Easy Upgrade' }
            ].map((feat, i) => (
              <div key={i} className="flex flex-col items-center p-6 bg-slate-50 dark:bg-slate-800 rounded-[35px] space-y-3">
                <div className="text-primary">{feat.icon}</div>
                <span className="text-[10px] font-black uppercase tracking-widest text-slate-400 dark:text-slate-500">{feat.text}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetails;
