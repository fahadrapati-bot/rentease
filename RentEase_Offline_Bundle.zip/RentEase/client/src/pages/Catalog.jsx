import React, { useState, useEffect } from 'react';
import api from '../api';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Filter, IndianRupee, Star, ArrowRight, Eye, X, Truck, ShieldCheck } from 'lucide-react';
import { Link } from 'react-router-dom';
import Viewer360 from '../components/Viewer360';

const Catalog = () => {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [category, setCategory] = useState('All');
  const [subCategory, setSubCategory] = useState('All');
  const [quickViewProduct, setQuickViewProduct] = useState(null);

  useEffect(() => {
    fetchProducts();
  }, []);

  const fetchProducts = async () => {
    try {
      const res = await api.get('/products');
      setProducts(res.data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const categories = ['All', ...new Set(products.map(p => p.category))];
  const subCategories = ['All', ...new Set(products
    .filter(p => category === 'All' || p.category === category)
    .map(p => p.sub_category)
    .filter(Boolean)
  )];

  const filteredProducts = products.filter(p => {
    const matchesSearch = p.name.toLowerCase().includes(search.toLowerCase());
    const matchesCategory = category === 'All' || p.category === category;
    const matchesSubCategory = subCategory === 'All' || p.sub_category === subCategory;
    return matchesSearch && matchesCategory && matchesSubCategory;
  });

  if (loading) return (
    <div className="min-h-screen flex items-center justify-center bg-white dark:bg-slate-950">
      <div className="animate-spin rounded-full h-12 w-12 border-t-4 border-primary"></div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20 bg-[#fcfcfd] dark:bg-slate-950 transition-colors duration-500">
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-10 mb-20">
        <div>
          <h1 className="text-6xl font-black text-slate-900 dark:text-white tracking-tight">Our Premium <br/><span className="text-primary text-glow">Inventory.</span></h1>
          <p className="text-slate-600 dark:text-slate-400 mt-6 text-xl max-w-xl font-medium">Curated collection of the finest furniture and appliances for your modern home.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-4 bg-white dark:bg-slate-900 p-4 rounded-3xl shadow-xl border border-slate-100 dark:border-slate-800">
          <div className="relative flex-grow">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <input 
              type="text"
              placeholder="Search..."
              className="pl-12 pr-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none w-full sm:w-60 focus:ring-2 focus:ring-primary outline-none transition-all font-bold text-slate-700 dark:text-slate-200"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </div>
          
          <div className="flex gap-4">
            <select 
              className="px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none focus:ring-2 focus:ring-primary font-black text-slate-700 dark:text-slate-200 appearance-none cursor-pointer min-w-[140px]"
              value={category}
              onChange={(e) => {
                setCategory(e.target.value);
                setSubCategory('All');
              }}
            >
              {categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select>

            <select 
              className="px-6 py-4 rounded-2xl bg-slate-50 dark:bg-slate-800 border-none outline-none focus:ring-2 focus:ring-primary font-black text-slate-700 dark:text-slate-200 appearance-none cursor-pointer min-w-[140px]"
              value={subCategory}
              onChange={(e) => setSubCategory(e.target.value)}
            >
              {subCategories.map(s => <option key={s} value={s}>{s}</option>)}
            </select>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-10">
        <AnimatePresence>
          {filteredProducts.map((p, idx) => (
            <motion.div 
              key={p.id}
              layout
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9 }}
              transition={{ duration: 0.5, delay: idx * 0.05 }}
              whileHover={{ y: -10 }}
              className="group bg-white dark:bg-slate-900 rounded-[40px] overflow-hidden shadow-sm hover:shadow-2xl transition-all border border-slate-100 dark:border-slate-800 flex flex-col h-full relative"
            >
              <div className="flex flex-col h-full">
                <div className="relative h-72 overflow-hidden">
                  <img 
                    src={p.image_url} 
                    alt={p.name} 
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-slate-900/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <button 
                      onClick={() => setQuickViewProduct(p)}
                      className="bg-white/90 backdrop-blur-md p-4 rounded-full shadow-2xl hover:scale-110 active:scale-95 transition-all text-slate-900 font-black flex items-center space-x-2"
                    >
                      <Eye className="h-6 w-6" />
                      <span className="text-sm pr-2">Quick View</span>
                    </button>
                  </div>
                  <div className="absolute top-6 left-6 bg-white/90 dark:bg-slate-800/90 backdrop-blur-md px-4 py-2 rounded-2xl text-xs font-black text-primary uppercase tracking-widest shadow-lg">
                    {p.sub_category || p.category}
                  </div>
                  <div className="absolute top-6 right-6 bg-slate-900/80 backdrop-blur-md px-3 py-2 rounded-2xl text-xs font-bold text-white flex items-center shadow-lg">
                    <Star className="h-3 w-3 text-orange-400 fill-current mr-1" /> 4.9
                  </div>
                </div>
                
                <Link to={`/product/${p.id}`} className="p-8 flex flex-col flex-grow">
                  <h3 className="text-2xl font-black text-slate-900 dark:text-white mb-3 group-hover:text-primary transition-colors">{p.name}</h3>
                  <p className="text-slate-500 dark:text-slate-400 text-sm mb-8 line-clamp-2 leading-relaxed font-medium">{p.description}</p>
                  
                  <div className="mt-auto flex items-center justify-between pt-6 border-t border-slate-50 dark:border-slate-800">
                    <div>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 block mb-1 uppercase font-black tracking-widest">Rent Per Month</span>
                      <div className="flex items-center text-3xl font-black text-slate-900 dark:text-white">
                        <IndianRupee className="h-5 w-5 text-primary" />
                        {p.monthly_rent}
                      </div>
                    </div>
                    <div className="bg-slate-900 dark:bg-slate-800 text-white h-14 w-14 rounded-2xl flex items-center justify-center group-hover:bg-primary transition-all group-hover:rotate-12">
                      <ArrowRight className="h-6 w-6" />
                    </div>
                  </div>
                </Link>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
      </div>
      
      {/* Quick View Modal */}
      <AnimatePresence>
        {quickViewProduct && (
          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-[200] flex items-center justify-center p-4"
            onClick={() => setQuickViewProduct(null)}
          >
            <motion.div 
              initial={{ scale: 0.9, y: 20 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.9, y: 20 }}
              className="bg-white dark:bg-slate-900 w-full max-w-5xl rounded-[60px] overflow-hidden shadow-2xl relative"
              onClick={(e) => e.stopPropagation()}
            >
              <button 
                onClick={() => setQuickViewProduct(null)}
                className="absolute top-8 right-8 z-30 p-4 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 rounded-full transition-colors"
              >
                <X className="h-6 w-6 text-slate-900 dark:text-white" />
              </button>

              <div className="grid grid-cols-1 md:grid-cols-2">
                <div className="p-10 bg-slate-50 dark:bg-slate-800/50">
                  <Viewer360 imageUrl={quickViewProduct.image_url} />
                </div>
                <div className="p-12 flex flex-col justify-center">
                  <span className="text-primary font-black uppercase text-xs tracking-[0.2em] mb-4">{quickViewProduct.sub_category || quickViewProduct.category}</span>
                  <h2 className="text-5xl font-black text-slate-900 dark:text-white mb-8 leading-tight">{quickViewProduct.name}</h2>
                  <p className="text-xl text-slate-500 dark:text-slate-400 font-medium leading-relaxed mb-12">{quickViewProduct.description}</p>
                  
                  <div className="flex items-center justify-between mb-12 bg-white dark:bg-slate-800 p-8 rounded-[40px] shadow-xl border border-slate-100 dark:border-slate-700">
                    <div>
                      <p className="text-slate-400 dark:text-slate-500 text-[10px] font-black uppercase tracking-widest mb-1">Starts at</p>
                      <div className="flex items-center text-4xl font-black text-slate-900 dark:text-white">
                        <IndianRupee className="h-6 w-6 text-primary" />
                        {quickViewProduct.monthly_rent}
                      </div>
                    </div>
                    <Link 
                      to={`/product/${quickViewProduct.id}`}
                      className="bg-slate-900 dark:bg-primary text-white px-10 py-5 rounded-2xl font-black text-lg hover:opacity-90 transition-all shadow-2xl shadow-slate-200 dark:shadow-none"
                    >
                      Rent Now
                    </Link>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-3xl flex items-center space-x-4">
                      <div className="bg-primary/10 p-3 rounded-xl text-primary"><Truck /></div>
                      <span className="text-sm font-black text-slate-700 dark:text-slate-300">Free 48h Setup</span>
                    </div>
                    <div className="bg-slate-50 dark:bg-slate-800 p-6 rounded-3xl flex items-center space-x-4">
                      <div className="bg-primary/10 p-3 rounded-xl text-primary"><ShieldCheck /></div>
                      <span className="text-sm font-black text-slate-700 dark:text-slate-300">Quality Insured</span>
                    </div>
                  </div>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>

      {filteredProducts.length === 0 && (
        <motion.div 
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-40 bg-white dark:bg-slate-900 rounded-[60px] border-4 border-dashed border-slate-100 dark:border-slate-800"
        >
          <p className="text-2xl font-black text-slate-300 dark:text-slate-700">Oops! No treasures found matching that search.</p>
          <button 
            onClick={() => {setSearch(''); setCategory('All'); setSubCategory('All');}}
            className="mt-6 text-primary font-bold hover:underline"
          >
            Clear all filters
          </button>
        </motion.div>
      )}
    </div>
  );
};

export default Catalog;
