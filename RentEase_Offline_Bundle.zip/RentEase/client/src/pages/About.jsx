import React from 'react';
import { motion } from 'framer-motion';
import { ShieldCheck, Truck, RotateCcw, Heart, Users, Globe } from 'lucide-react';

const About = () => {
  return (
    <div className="bg-white dark:bg-slate-950">
      {/* Header */}
      <section className="py-20 bg-slate-50 dark:bg-slate-900/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-black text-slate-900 dark:text-white mb-6"
          >
            Redefining Urban Living
          </motion.h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 max-w-3xl mx-auto leading-relaxed">
            RentEase was founded on the belief that everyone deserves a beautiful home, 
            without the financial burden of ownership or the stress of relocation.
          </p>
        </div>
      </section>

      {/* Our Mission */}
      <section className="py-24">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-16 items-center">
            <div className="space-y-8">
              <h2 className="text-4xl font-bold text-slate-900 dark:text-white">Our Mission</h2>
              <p className="text-lg text-slate-600 dark:text-slate-400 leading-relaxed">
                We're on a mission to promote sustainable consumption and affordable living. 
                By providing a flexible rental ecosystem, we help students and professionals 
                set up their dream homes instantly and move effortlessly.
              </p>
              <div className="space-y-4">
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-xl text-primary">
                    <Heart className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">Customer Obsessed</h4>
                    <p className="text-slate-500 dark:text-slate-400">We put your comfort and convenience at the center of everything we do.</p>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="bg-primary/10 p-3 rounded-xl text-primary">
                    <Globe className="h-6 w-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white">Sustainability First</h4>
                    <p className="text-slate-500 dark:text-slate-400">Reducing waste by extending the lifecycle of premium products.</p>
                  </div>
                </div>
              </div>
            </div>
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1524758631624-e2822e304c36?w=800&q=80" 
                alt="Living Room" 
                className="rounded-[40px] shadow-2xl"
              />
              <div className="absolute -bottom-10 -left-10 bg-white dark:bg-slate-900 p-8 rounded-3xl shadow-xl dark:shadow-none hidden lg:block border border-slate-100 dark:border-slate-800">
                <div className="flex items-center space-x-4">
                  <div className="text-4xl font-black text-primary">10k+</div>
                  <div className="text-slate-500 dark:text-slate-400 text-sm font-bold uppercase leading-tight">Happy<br/>Customers</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* How it Works */}
      <section className="py-24 bg-slate-900 text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-4xl font-bold text-center mb-20">How RentEase Works</h2>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-12">
            {[
              { step: '01', title: 'Pick & Choose', desc: 'Select from our wide range of furniture and appliances.' },
              { step: '02', title: 'Select Tenure', desc: 'Choose a rental period that fits your stay (3-24 months).' },
              { step: '03', title: 'Free Delivery', desc: 'We deliver and install everything within 48 hours.' },
              { step: '04', title: 'Live Comfortably', desc: 'Enjoy your home. We handle the maintenance for you.' },
            ].map((item, idx) => (
              <div key={idx} className="relative">
                <span className="text-8xl font-black text-white/5 absolute -top-10 -left-4">{item.step}</span>
                <h3 className="text-xl font-bold mb-4 relative z-10">{item.title}</h3>
                <p className="text-slate-400 relative z-10">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team/Support Section */}
      <section className="py-24 bg-white dark:bg-slate-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold text-slate-900 dark:text-white mb-12">Ready to Upgrade?</h2>
          <p className="text-xl text-slate-500 dark:text-slate-400 mb-10">Join thousands of people who have simplified their lives with RentEase.</p>
          <div className="flex justify-center space-x-6">
            <button className="bg-primary text-white px-10 py-5 rounded-2xl font-black text-xl hover:bg-primary-dark transition-all shadow-xl shadow-primary/20">
              Get Started Now
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};

export default About;
