import React from 'react';
import { Link } from 'react-router-dom';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, Sofa, Tv, Bed, Truck, ShieldCheck, Clock, Star, Zap } from 'lucide-react';

const categories = [
  { 
    name: 'Living Spaces', 
    icon: <Sofa className="h-8 w-8" />, 
    color: 'bg-orange-100 text-orange-600',
    image: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&q=80&w=1000'
  },
  { 
    name: 'Smart Kitchen', 
    icon: <Tv className="h-8 w-8" />, 
    color: 'bg-blue-100 text-blue-600',
    image: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&q=80&w=1000'
  },
  { 
    name: 'Master Bedroom', 
    icon: <Bed className="h-8 w-8" />, 
    color: 'bg-indigo-100 text-indigo-600',
    image: 'https://images.unsplash.com/photo-1505693419148-4030a90441c9?auto=format&fit=crop&q=80&w=1000'
  },
];

const Home = () => {
  const { scrollY } = useScroll();
  const y1 = useTransform(scrollY, [0, 500], [0, 200]);
  const rotate = useTransform(scrollY, [0, 500], [0, 10]);

  return (
    <div className="space-y-32 pb-32 bg-[#fcfcfd] dark:bg-slate-950 transition-colors duration-500 overflow-hidden">
      {/* 3D Hero Section */}
      <section className="relative min-h-[90vh] flex items-center pt-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10 w-full">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, x: -50 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.8, ease: "easeOut" }}
            >
              <div className="inline-flex items-center space-x-2 bg-primary/10 text-primary px-4 py-2 rounded-full mb-6 font-bold text-sm">
                <Zap className="h-4 w-4" />
                <span>Future of Urban Living</span>
              </div>
              <h1 className="text-7xl font-black text-slate-900 dark:text-white leading-[1.1] tracking-tight">
                Live Better. <br />
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-blue-600 text-glow">Own Nothing.</span>
              </h1>
              <p className="mt-8 text-xl text-slate-600 dark:text-slate-400 leading-relaxed max-w-xl font-medium">
                Access premium furniture and high-end appliances for a fraction of the cost. Free delivery, easy maintenance, and the freedom to move whenever you want.
              </p>
              <div className="mt-12 flex flex-col sm:flex-row space-y-4 sm:space-y-0 sm:space-x-6">
                <Link to="/catalog" className="group relative bg-slate-900 dark:bg-primary text-white px-10 py-5 rounded-2xl font-black text-lg transition-all hover:scale-105 active:scale-95 shadow-2xl shadow-slate-200 dark:shadow-none overflow-hidden">
                  <span className="relative z-10 flex items-center justify-center">
                    Start Renting <ArrowRight className="ml-2 h-5 w-5 group-hover:translate-x-2 transition-transform" />
                  </span>
                  <div className="absolute inset-0 bg-gradient-to-r from-primary to-blue-500 opacity-0 group-hover:opacity-100 transition-opacity" />
                </Link>
                <Link to="/about" className="bg-white dark:bg-slate-800 text-slate-900 dark:text-white px-10 py-5 rounded-2xl font-black text-lg transition-all hover:bg-slate-50 dark:hover:bg-slate-700 border border-slate-200 dark:border-slate-700 flex items-center justify-center">
                  Learn More
                </Link>
              </div>
              
              <div className="mt-16 flex items-center space-x-8">
                <div className="flex -space-x-4">
                  {[1,2,3,4].map(i => (
                    <img key={i} src={`https://i.pravatar.cc/100?img=${i+10}`} className="h-12 w-12 rounded-full border-4 border-white dark:border-slate-800 object-cover" alt="" />
                  ))}
                </div>
                <div>
                  <div className="flex text-orange-400">
                    {[1,2,3,4,5].map(i => <Star key={i} className="h-4 w-4 fill-current" />)}
                  </div>
                  <p className="text-sm font-bold text-slate-900 dark:text-slate-300 mt-1 uppercase tracking-wider">Trusted by 2,000+ happy tenants</p>
                </div>
              </div>
            </motion.div>

            <motion.div 
              style={{ y: y1, rotateX: rotate, rotateY: rotate }}
              className="relative hidden lg:block perspective-1000"
            >
              <motion.div
                initial={{ opacity: 0, scale: 0.8, rotateY: 20 }}
                animate={{ opacity: 1, scale: 1, rotateY: 0 }}
                transition={{ duration: 1, delay: 0.2 }}
                className="relative z-10"
              >
                <img 
                  src="https://images.unsplash.com/photo-1524758631624-e2822e304c36?auto=format&fit=crop&q=80&w=1200" 
                  alt="Modern Furniture" 
                  className="rounded-[60px] shadow-[0_50px_100px_-20px_rgba(0,0,0,0.3)] transform-style-3d border-8 border-white dark:border-slate-800"
                />
                
                {/* Floating Elements */}
                <motion.div 
                  animate={{ y: [0, -20, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }}
                  className="absolute -top-10 -right-10 bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-700 z-20"
                >
                  <div className="bg-orange-100 dark:bg-orange-900/30 p-3 rounded-2xl inline-block mb-3">
                    <Sofa className="text-orange-600 dark:text-orange-400" />
                  </div>
                  <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Premium Choice</p>
                  <p className="text-lg font-black text-slate-900 dark:text-white">Velvet Sofa</p>
                </motion.div>

                <motion.div 
                  animate={{ y: [0, 20, 0] }}
                  transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 1 }}
                  className="absolute -bottom-10 -left-10 bg-white dark:bg-slate-800 p-6 rounded-3xl shadow-2xl border border-slate-100 dark:border-slate-700 z-20"
                >
                  <div className="bg-blue-100 dark:bg-blue-900/30 p-3 rounded-2xl inline-block mb-3">
                    <Tv className="text-blue-600 dark:text-blue-400" />
                  </div>
                  <p className="text-xs font-bold text-slate-400 dark:text-slate-500 uppercase tracking-widest">Top Rated</p>
                  <p className="text-lg font-black text-slate-900 dark:text-white">4K Smart TV</p>
                </motion.div>
              </motion.div>

              {/* Decorative Blur */}
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-primary/20 dark:bg-primary/10 blur-[120px] -z-10 rounded-full" />
            </motion.div>
          </div>
        </div>
      </section>

      {/* Categories with 3D Hover */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-5xl font-black text-slate-900 dark:text-white mb-4 tracking-tight">Explore our curated collections</h2>
          <p className="text-slate-500 dark:text-slate-400 max-w-2xl mx-auto text-xl font-medium">Choose from categories that suit your taste and lifestyle.</p>
        </div>
        
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
          {categories.map((cat, idx) => (
            <motion.div 
              key={idx}
              whileHover={{ y: -15, rotateX: 5, rotateY: 5 }}
              className="relative group h-[500px] rounded-[40px] overflow-hidden shadow-lg hover:shadow-2xl transition-all cursor-pointer perspective-1000 transform-style-3d"
            >
              <img src={cat.image} className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" alt="" />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/90 via-slate-900/20 to-transparent" />
              
              <div className="absolute bottom-0 left-0 right-0 p-10 transform-style-3d translate-z-20">
                <div className={`w-16 h-16 rounded-2xl flex items-center justify-center mb-6 transition-colors shadow-lg ${cat.color} dark:bg-opacity-20`}>
                  {cat.icon}
                </div>
                <h3 className="text-3xl font-black text-white mb-2">{cat.name}</h3>
                <p className="text-slate-300 mb-6 font-medium leading-relaxed">Explore the best of {cat.name.toLowerCase()} design.</p>
                <Link to="/catalog" className="flex items-center text-primary font-black text-lg group-hover:translate-x-2 transition-transform">
                  View Collection <ArrowRight className="ml-2 h-5 w-5" />
                </Link>
              </div>
            </motion.div>
          ))}
        </div>

        {/* Custom Request CTA */}
        <motion.div 
          initial={{ y: 30, opacity: 0 }}
          whileInView={{ y: 0, opacity: 1 }}
          className="mt-20 bg-slate-900 dark:bg-primary p-12 rounded-[50px] text-white flex flex-col md:flex-row items-center justify-between shadow-2xl relative overflow-hidden group"
        >
          <div className="relative z-10">
            <h3 className="text-4xl font-black mb-4">Can't find what you need?</h3>
            <p className="text-slate-300 dark:text-white/80 text-xl font-medium max-w-xl">
              We can source specific furniture types just for you. Just upload an image and we'll handle the rest.
            </p>
          </div>
          <Link to="/custom-request" className="mt-8 md:mt-0 relative z-10 bg-white text-slate-900 px-10 py-5 rounded-2xl font-black text-lg hover:scale-105 transition-all flex items-center space-x-2 shadow-xl">
            <span>Try Furniture Finder</span>
            <ArrowRight className="h-5 w-5" />
          </Link>
          <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full blur-3xl -mr-32 -mt-32 group-hover:scale-150 transition-transform duration-1000" />
        </motion.div>
      </section>

      {/* Glassmorphism Why Choose Us */}
      <section className="relative py-32 overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-full bg-slate-900 dark:bg-slate-900/50 -z-10" />
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
            <div className="relative">
              <motion.div 
                whileInView={{ rotate: 0 }}
                viewport={{ once: true }}
                className="bg-white/10 backdrop-blur-xl p-12 rounded-[50px] border border-white/20 shadow-2xl relative z-10"
              >
                <h2 className="text-5xl font-black text-white mb-10 leading-tight">Why the world is <br/><span className="text-primary">renting with us.</span></h2>
                <div className="space-y-10">
                  <div className="flex space-x-6">
                    <div className="bg-primary/20 p-4 rounded-2xl text-primary h-fit">
                      <Truck className="h-8 w-8" />
                    </div>
                    <div>
                      <h4 className="text-2xl font-bold text-white mb-2">Swift Setup</h4>
                      <p className="text-slate-400 font-medium">Order today, live tomorrow. We deliver and install within 48 hours for free.</p>
                    </div>
                  </div>
                  <div className="flex space-x-6">
                    <div className="bg-primary/20 p-4 rounded-2xl text-primary h-fit">
                      <ShieldCheck className="h-8 w-8" />
                    </div>
                    <div>
                      <h4 className="text-2xl font-bold text-white mb-2">Zero Worry</h4>
                      <p className="text-slate-400 font-medium">Broken? Scratched? We offer full maintenance and repair support at your door.</p>
                    </div>
                  </div>
                </div>
              </motion.div>
              {/* Decorative elements */}
              <div className="absolute -top-20 -right-20 w-64 h-64 bg-primary/30 rounded-full blur-[100px] animate-pulse" />
            </div>
            
            <div className="text-white space-y-8">
              <div className="bg-slate-800/50 p-8 rounded-3xl border border-slate-700 group hover:bg-slate-800 transition-colors">
                <p className="text-5xl font-black mb-2 text-primary">98%</p>
                <p className="text-slate-400 font-black uppercase tracking-widest text-sm">Satisfaction Rate</p>
              </div>
              <div className="bg-slate-800/50 p-8 rounded-3xl border border-slate-700 group hover:bg-slate-800 transition-colors">
                <p className="text-5xl font-black mb-2 text-primary">₹12 Cr+</p>
                <p className="text-slate-400 font-black uppercase tracking-widest text-sm">Security Deposits Saved</p>
              </div>
              <div className="bg-slate-800/50 p-8 rounded-3xl border border-slate-700 group hover:bg-slate-800 transition-colors">
                <p className="text-5xl font-black mb-2 text-primary">15+</p>
                <p className="text-slate-400 font-black uppercase tracking-widest text-sm">Cities Covered</p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
