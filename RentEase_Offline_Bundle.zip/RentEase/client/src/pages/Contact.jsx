import React from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageSquare } from 'lucide-react';

const Contact = () => {
  return (
    <div className="bg-[#fcfcfd] dark:bg-slate-950 py-24">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-20">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-6xl font-black text-slate-900 dark:text-white mb-6"
          >
            Get in <span className="text-primary">Touch.</span>
          </motion.h1>
          <p className="text-xl text-slate-500 dark:text-slate-400 max-w-2xl mx-auto font-medium">
            Have questions about our rental plans or need maintenance support? 
            Our team is here to help you 24/7.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-20">
          {/* Contact Info */}
          <div className="space-y-12">
            <div className="bg-white dark:bg-slate-900 p-10 rounded-[40px] shadow-xl dark:shadow-none border border-slate-100 dark:border-slate-800 flex items-start space-x-6">
              <div className="bg-primary/10 p-4 rounded-2xl text-primary">
                <Mail className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Email Us</h3>
                <p className="text-slate-500 dark:text-slate-400 font-medium">support@rentease.com</p>
                <p className="text-slate-500 dark:text-slate-400 font-medium">concierge@rentease.com</p>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-10 rounded-[40px] shadow-xl dark:shadow-none border border-slate-100 dark:border-slate-800 flex items-start space-x-6">
              <div className="bg-primary/10 p-4 rounded-2xl text-primary">
                <Phone className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Call Us</h3>
                <p className="text-slate-500 dark:text-slate-400 font-medium">+91 (800) 123-4567</p>
                <p className="text-slate-500 dark:text-slate-400 font-medium">Mon - Sun, 9am - 9pm</p>
              </div>
            </div>

            <div className="bg-white dark:bg-slate-900 p-10 rounded-[40px] shadow-xl dark:shadow-none border border-slate-100 dark:border-slate-800 flex items-start space-x-6">
              <div className="bg-primary/10 p-4 rounded-2xl text-primary">
                <MapPin className="h-8 w-8" />
              </div>
              <div>
                <h3 className="text-2xl font-bold text-slate-900 dark:text-white mb-2">Our Office</h3>
                <p className="text-slate-500 dark:text-slate-400 font-medium">123 Design District, Tech Park</p>
                <p className="text-slate-500 dark:text-slate-400 font-medium">Bengaluru, KA 560100</p>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="bg-slate-900 rounded-[50px] p-12 shadow-2xl relative overflow-hidden">
            <h2 className="text-3xl font-black text-white mb-8 relative z-10">Send a Message</h2>
            <form className="space-y-6 relative z-10">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <input 
                  type="text" 
                  placeholder="Your Name"
                  className="w-full px-6 py-4 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-primary transition-all font-bold"
                />
                <input 
                  type="email" 
                  placeholder="Your Email"
                  className="w-full px-6 py-4 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-primary transition-all font-bold"
                />
              </div>
              <select className="w-full px-6 py-4 rounded-2xl bg-white/10 border border-white/20 text-white outline-none focus:ring-2 focus:ring-primary font-bold appearance-none">
                <option className="bg-slate-900">General Inquiry</option>
                <option className="bg-slate-900">Maintenance Request</option>
                <option className="bg-slate-900">Partnership</option>
              </select>
              <textarea 
                rows="5"
                placeholder="How can we help?"
                className="w-full px-6 py-4 rounded-2xl bg-white/10 border border-white/20 text-white placeholder:text-slate-500 outline-none focus:ring-2 focus:ring-primary transition-all font-bold"
              ></textarea>
              <button className="w-full bg-primary text-white py-5 rounded-2xl font-black text-xl hover:bg-primary-dark transition-all flex items-center justify-center shadow-xl shadow-primary/20 group">
                Send Message <Send className="ml-2 h-5 w-5 group-hover:translate-x-1 transition-transform" />
              </button>
            </form>
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/10 rounded-full blur-[100px] -mr-32 -mt-32" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Contact;
