import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';
import { useTheme } from './context/ThemeContext';
import { AnimatePresence, motion } from 'framer-motion';
import { Camera, Send, MessageCircle, Smartphone, Moon, Sun, Apple, Play, Share2, Globe, Heart } from 'lucide-react';
import Navbar from './components/Navbar';
import Home from './pages/Home';
import Catalog from './pages/Catalog';
import ProductDetails from './pages/ProductDetails';
import CustomRequest from './pages/CustomRequest';
import ForgotPassword from './pages/ForgotPassword';
import About from './pages/About';
import FAQ from './pages/FAQ';
import Contact from './pages/Contact';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import AdminDashboard from './pages/AdminDashboard';
import Relocation from './pages/Relocation';
import Privacy from './pages/Privacy';
import Wishlist from './pages/Wishlist';
import Chatbot from './components/Chatbot';
import LoadingScreen from './components/LoadingScreen';

const FloatingActions = () => {
  return (
    <div className="fixed left-8 bottom-8 z-[100] hidden xl:flex flex-col space-y-4">
      {[
        { icon: <Camera className="h-5 w-5" />, color: 'hover:bg-pink-600', label: 'Instagram' },
        { icon: <Globe className="h-5 w-5" />, color: 'hover:bg-blue-600', label: 'Facebook' },
        { icon: <Send className="h-5 w-5" />, color: 'hover:bg-sky-500', label: 'Twitter' },
        { icon: <MessageCircle className="h-5 w-5" />, color: 'hover:bg-green-500', label: 'WhatsApp' }
      ].map((social, i) => (
        <motion.div
          key={i}
          whileHover={{ x: 10, scale: 1.1 }}
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 1 + i * 0.1 }}
          className={`group h-12 w-12 bg-white dark:bg-slate-800 rounded-2xl flex items-center justify-center shadow-2xl cursor-pointer transition-all border border-slate-100 dark:border-slate-700 text-slate-400 hover:text-white relative`}
        >
          <div className={`${social.color} w-full h-full flex items-center justify-center rounded-2xl transition-colors`}>
            {social.icon}
          </div>
          <div className="absolute left-full ml-4 px-3 py-1 bg-slate-900 text-white text-[10px] font-black rounded-lg opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none uppercase tracking-widest whitespace-nowrap">
            {social.label}
          </div>
        </motion.div>
      ))}
    </div>
  );
};

const PageTransition = ({ children }) => {
  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  );
};

const AnimatedRoutes = () => {
  const location = useLocation();
  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        <Route path="/" element={<PageTransition><Home /></PageTransition>} />
        <Route path="/catalog" element={<PageTransition><Catalog /></PageTransition>} />
        <Route path="/product/:id" element={<PageTransition><ProductDetails /></PageTransition>} />
        <Route path="/custom-request" element={<PageTransition><CustomRequest /></PageTransition>} />
        <Route path="/forgot-password" element={<PageTransition><ForgotPassword /></PageTransition>} />
        <Route path="/about" element={<PageTransition><About /></PageTransition>} />
        <Route path="/faq" element={<PageTransition><FAQ /></PageTransition>} />
        <Route path="/contact" element={<PageTransition><Contact /></PageTransition>} />
        <Route path="/relocation" element={<PageTransition><Relocation /></PageTransition>} />
        <Route path="/privacy" element={<PageTransition><Privacy /></PageTransition>} />
        <Route path="/wishlist" element={<PageTransition><Wishlist /></PageTransition>} />
        <Route path="/login" element={<PageTransition><Login /></PageTransition>} />
        <Route path="/dashboard" element={<PageTransition><Dashboard /></PageTransition>} />
        <Route path="/admin" element={<PageTransition><AdminDashboard /></PageTransition>} />
      </Routes>
    </AnimatePresence>
  );
};

function App() {
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setLoading(false);
    }, 2500);
    return () => clearTimeout(timer);
  }, []);

  return (
    <AuthProvider>
      <AnimatePresence>
        {loading && <LoadingScreen />}
      </AnimatePresence>
      <Router>
        <div className="min-h-screen flex flex-col bg-slate-50 dark:bg-slate-950 transition-colors duration-500">
          <Navbar />
          <FloatingActions />
          <Chatbot />
          <main className="flex-grow">
            <AnimatedRoutes />
          </main>
          <footer className="bg-white dark:bg-slate-900 border-t border-slate-100 dark:border-slate-800 py-24">
            <div className="max-w-7xl mx-auto px-4 grid grid-cols-1 md:grid-cols-4 gap-16">
              <div className="space-y-8">
                <h2 className="text-4xl font-black text-slate-900 dark:text-white tracking-tighter text-glow text-primary">RentEase</h2>
                <p className="text-slate-600 dark:text-slate-400 font-medium leading-relaxed">
                  The future of urban living. Access premium lifestyle products with complete freedom and flexibility.
                </p>
                <div className="pt-4">
                  <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em] mb-4">Customer Care 24/7</p>
                  <a href="tel:7433991182" className="text-2xl font-black text-slate-900 dark:text-white hover:text-primary transition-colors">
                    +91 7433991182
                  </a>
                </div>
                <div className="flex space-x-4">
                  {[
                    { icon: <Camera className="h-5 w-5" />, color: 'hover:text-pink-600' },
                    { icon: <Globe className="h-5 w-5" />, color: 'hover:text-blue-600' },
                    { icon: <Send className="h-5 w-5" />, color: 'hover:text-sky-500' },
                    { icon: <MessageCircle className="h-5 w-5" />, color: 'hover:text-green-500' }
                  ].map((social, i) => (
                    <div key={i} className={`h-12 w-12 bg-slate-50 dark:bg-slate-800 rounded-2xl flex items-center justify-center transition-all cursor-pointer border border-slate-100 dark:border-slate-700 hover:bg-white dark:hover:bg-slate-700 hover:shadow-xl active:scale-90 text-slate-400 dark:text-slate-500`}>
                      {social.icon}
                    </div>
                  ))}
                </div>
              </div>
              <div>
                <h4 className="font-black text-slate-900 dark:text-white mb-8 uppercase tracking-widest text-xs">Explore</h4>
                <ul className="space-y-4 text-slate-600 dark:text-slate-400 font-bold text-sm">
                  <li><a href="/catalog" className="hover:text-primary transition-colors">Premium Catalog</a></li>
                  <li><a href="/custom-request" className="hover:text-primary transition-colors font-black">Furniture Finder</a></li>
                  <li><a href="/relocation" className="hover:text-primary transition-colors">Relocation Support</a></li>
                  <li><a href="/faq" className="hover:text-primary transition-colors">Help Center</a></li>
                </ul>
              </div>
              <div>
                <h4 className="font-black text-slate-900 dark:text-white mb-8 uppercase tracking-widest text-xs">Trust</h4>
                <ul className="space-y-4 text-slate-600 dark:text-slate-400 font-bold text-sm">
                  <li><a href="/about" className="hover:text-primary transition-colors">Our Mission</a></li>
                  <li><a href="/privacy" className="hover:text-primary transition-colors">Privacy & Security</a></li>
                  <li><a href="/contact" className="hover:text-primary transition-colors">Get in Touch</a></li>
                </ul>
              </div>
              <div>
                <h4 className="font-black text-slate-900 dark:text-white mb-8 uppercase tracking-widest text-xs">Download App</h4>
                <div className="space-y-4">
                  <div className="bg-slate-900 dark:bg-slate-800 p-4 rounded-2xl flex items-center space-x-4 cursor-pointer hover:bg-slate-800 dark:hover:bg-slate-700 transition-colors shadow-xl border border-white/5">
                    <div className="h-10 w-10 bg-white/10 rounded-xl flex items-center justify-center text-white"><Apple className="h-6 w-6" /></div>
                    <div className="text-white">
                      <p className="text-[10px] font-bold opacity-50 uppercase tracking-widest">Get it on</p>
                      <p className="font-black">App Store</p>
                    </div>
                  </div>
                  <div className="bg-slate-900 dark:bg-slate-800 p-4 rounded-2xl flex items-center space-x-4 cursor-pointer hover:bg-slate-800 dark:hover:bg-slate-700 transition-colors shadow-xl border border-white/5">
                    <div className="h-10 w-10 bg-white/10 rounded-xl flex items-center justify-center text-white"><Play className="h-6 w-6 fill-current" /></div>
                    <div className="text-white">
                      <p className="text-[10px] font-bold opacity-50 uppercase tracking-widest">Get it on</p>
                      <p className="font-black">Google Play</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="max-w-7xl mx-auto px-4 mt-24 pt-10 border-t border-slate-50 dark:border-slate-800 flex flex-col md:flex-row justify-between items-center text-slate-400 dark:text-slate-500 text-sm font-bold">
              <p>© 2026 RentEase – Design with Passion</p>
              <div className="flex space-x-8 mt-4 md:mt-0">
                <a href="/privacy" className="hover:text-slate-900 dark:hover:text-white">Terms</a>
                <a href="/privacy" className="hover:text-slate-900 dark:hover:text-white">Privacy</a>
                <a href="/privacy" className="hover:text-slate-900 dark:hover:text-white">Cookies</a>
              </div>
            </div>
          </footer>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
