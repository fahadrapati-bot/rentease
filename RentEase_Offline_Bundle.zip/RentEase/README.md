# RentEase – Furniture & Appliance Rental Platform

## Overview
RentEase is a full-stack web application designed for students and working professionals to rent premium furniture and appliances with flexible tenure plans.

## Tech Stack
- **Frontend:** React.js, Tailwind CSS, Framer Motion, Lucide Icons, Vite
- **Backend:** Node.js, Express.js
- **Database:** SQLite (SQL)
- **State Management:** React Context API
- **Auth:** JWT with Bcrypt password hashing

## Features
- **Modern UI:** Professional, clean, and mobile-first design.
- **Product Catalog:** Browse by category, search, and detailed product views.
- **Rental System:** Choose tenure (3, 6, 12, 24 months) and schedule delivery.
- **User Dashboard:** Track active rentals and request maintenance.
- **Admin Panel:** Manage inventory (CRUD) and monitor business stats.

## Setup Instructions

### Prerequisites
- Node.js installed

### Backend Setup
1. Navigate to `server/`
2. Install dependencies: `npm install`
3. Seed database: `node seed.js`
4. Start server: `node index.js` (Runs on port 5000)

### Frontend Setup
1. Navigate to `client/`
2. Install dependencies: `npm install`
3. Start development server: `npm run dev` (Runs on port 5173)

## API Endpoints
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/products` - List all products
- `POST /api/products` - Add new product (Admin)
- `GET /api/rentals/user/:id` - Get user rentals
- `POST /api/rentals` - Create new rental
- `POST /api/maintenance` - Submit maintenance request
