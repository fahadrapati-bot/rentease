# Product Requirements Document (PRD) - RentEase

## 1. Product Vision
To become the most trusted and convenient platform for furniture and appliance rentals, enabling urban dwellers to live comfortably without the burden of ownership.

## 2. Problem Statement
Relocating professionals and students face high upfront costs and logistical nightmares when buying furniture. Existing options are often fragmented, expensive, or lack support.

## 3. Target Audience
- **Students:** Temporary residents looking for affordable living.
- **Working Professionals:** Frequent relocators who value convenience and flexibility.

## 4. Key Functional Requirements
### User Side
- **Catalog Browsing:** Filter by categories and search for items.
- **Dynamic Pricing:** Transparent view of monthly rent and security deposits.
- **Rental Management:** Easy checkout with tenure selection and delivery scheduling.
- **Self-Service:** Request maintenance or view rental history via dashboard.

### Admin Side
- **Inventory Control:** Full CRUD operations on products.
- **Analytics:** High-level overview of revenue and utilization.
- **Order Monitoring:** Track the lifecycle of all rentals.

## 5. Non-Functional Requirements
- **Performance:** Optimized React components for <2s page loads.
- **Scalability:** SQLite for MVP, structured for easy PostgreSQL migration.
- **Usability:** Mobile-first responsive design using Tailwind CSS.

## 6. Success Metrics (KPIs)
- **Product Utilization:** % of inventory currently rented.
- **User Retention:** Rate of rental extensions.
- **Resolution Time:** Time taken to close maintenance requests.
