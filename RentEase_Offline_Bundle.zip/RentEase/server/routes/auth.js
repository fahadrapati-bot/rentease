import express from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';

const router = express.Router();

router.post('/register', async (req, res) => {
  const { name, email, phone, password, role } = req.body;
  const db = req.app.locals.db;

  try {
    const hashedPassword = await bcrypt.hash(password, 10);
    await db.run(
      'INSERT INTO users (name, email, phone, password, role) VALUES (?, ?, ?, ?, ?)',
      [name, email, phone, hashedPassword, role || 'user']
    );
    res.status(201).json({ message: 'User registered successfully' });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return res.status(400).json({ error: 'Email or Phone already exists' });
    }
    res.status(500).json({ error: 'Registration failed' });
  }
});

router.post('/forgot-password', async (req, res) => {
  const { identifier } = req.body; // Can be email or phone
  const db = req.app.locals.db;

  try {
    const user = await db.get('SELECT * FROM users WHERE email = ? OR phone = ?', [identifier, identifier]);
    if (!user) return res.status(400).json({ error: 'User not found' });

    const otp = Math.floor(100000 + Math.random() * 900000).toString();
    const expiresAt = new Date(Date.now() + 10 * 60000); // 10 mins

    await db.run('DELETE FROM otp_codes WHERE identifier = ?', [identifier]);
    await db.run('INSERT INTO otp_codes (identifier, code, expires_at) VALUES (?, ?, ?)', [identifier, otp, expiresAt]);

    console.log(`[SIMULATED SMS/EMAIL] To: ${identifier}, Code: ${otp}`);
    res.json({ message: `Verification code sent to ${identifier}` });
  } catch (error) {
    res.status(500).json({ error: 'Failed to process request' });
  }
});

router.post('/verify-otp', async (req, res) => {
  const { identifier, code } = req.body;
  const db = req.app.locals.db;

  try {
    const record = await db.get('SELECT * FROM otp_codes WHERE identifier = ? AND code = ?', [identifier, code]);
    if (!record) return res.status(400).json({ error: 'Invalid or expired code' });

    if (new Date(record.expires_at) < new Date()) {
      return res.status(400).json({ error: 'Code has expired' });
    }

    res.json({ message: 'Code verified successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Verification failed' });
  }
});

router.post('/reset-password', async (req, res) => {
  const { identifier, code, newPassword } = req.body;
  const db = req.app.locals.db;

  try {
    const record = await db.get('SELECT * FROM otp_codes WHERE identifier = ? AND code = ?', [identifier, code]);
    if (!record) return res.status(400).json({ error: 'Invalid verification' });

    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await db.run('UPDATE users SET password = ? WHERE email = ? OR phone = ?', [hashedPassword, identifier, identifier]);
    await db.run('DELETE FROM otp_codes WHERE identifier = ?', [identifier]);

    res.json({ message: 'Password reset successful' });
  } catch (error) {
    res.status(500).json({ error: 'Reset failed' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  const db = req.app.locals.db;

  try {
    const user = await db.get('SELECT * FROM users WHERE email = ?', [email]);
    if (!user) return res.status(400).json({ error: 'Invalid credentials' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) return res.status(400).json({ error: 'Invalid credentials' });

    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({
      token,
      user: { id: user.id, name: user.name, email: user.email, role: user.role }
    });
  } catch (error) {
    res.status(500).json({ error: 'Login failed' });
  }
});

export default router;
