import express from 'express';

const router = express.Router();

// Create rental
router.post('/', async (req, res) => {
  const { user_id, product_id, tenure_months, start_date, end_date, delivery_date, total_price } = req.body;
  const db = req.app.locals.db;
  try {
    const result = await db.run(
      'INSERT INTO rentals (user_id, product_id, tenure_months, start_date, end_date, delivery_date, total_price) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [user_id, product_id, tenure_months, start_date, end_date, delivery_date, total_price]
    );
    res.status(201).json({ id: result.lastID, message: 'Rental created successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to create rental' });
  }
});

// Get user rentals
router.get('/user/:userId', async (req, res) => {
  const db = req.app.locals.db;
  try {
    const rentals = await db.all(`
      SELECT rentals.*, products.name as product_name, products.image_url 
      FROM rentals 
      JOIN products ON rentals.product_id = products.id 
      WHERE rentals.user_id = ?`, 
      [req.params.userId]
    );
    res.json(rentals);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch rentals' });
  }
});

export default router;
