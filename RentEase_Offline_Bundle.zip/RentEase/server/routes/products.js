import express from 'express';

const router = express.Router();

// Get all products
router.get('/', async (req, res) => {
  const db = req.app.locals.db;
  try {
    const products = await db.all('SELECT * FROM products');
    res.json(products);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch products' });
  }
});

// Get single product
router.get('/:id', async (req, res) => {
  const db = req.app.locals.db;
  try {
    const product = await db.get('SELECT * FROM products WHERE id = ?', [req.params.id]);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch product' });
  }
});

// Admin: Add product
router.post('/', async (req, res) => {
  const { name, category, sub_category, description, monthly_rent, security_deposit, stock, image_url } = req.body;
  const db = req.app.locals.db;
  try {
    const result = await db.run(
      'INSERT INTO products (name, category, sub_category, description, monthly_rent, security_deposit, stock, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [name, category, sub_category, description, monthly_rent, security_deposit, stock, image_url]
    );
    res.status(201).json({ id: result.lastID, message: 'Product added successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to add product' });
  }
});

export default router;
