import express from 'express';

const router = express.Router();

router.post('/', async (req, res) => {
  const { user_id, product_id } = req.body;
  const db = req.app.locals.db;
  try {
    await db.run(
      'INSERT INTO favorites (user_id, product_id) VALUES (?, ?)',
      [user_id, product_id]
    );
    res.status(201).json({ message: 'Added to wishlist' });
  } catch (error) {
    if (error.message.includes('UNIQUE constraint failed')) {
      return res.status(400).json({ error: 'Already in wishlist' });
    }
    res.status(500).json({ error: 'Failed to add to wishlist' });
  }
});

router.get('/user/:userId', async (req, res) => {
  const db = req.app.locals.db;
  try {
    const favorites = await db.all(`
      SELECT products.* 
      FROM favorites 
      JOIN products ON favorites.product_id = products.id 
      WHERE favorites.user_id = ?`, 
      [req.params.userId]
    );
    res.json(favorites);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch wishlist' });
  }
});

router.delete('/:userId/:productId', async (req, res) => {
  const db = req.app.locals.db;
  try {
    await db.run(
      'DELETE FROM favorites WHERE user_id = ? AND product_id = ?',
      [req.params.userId, req.params.productId]
    );
    res.json({ message: 'Removed from wishlist' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to remove from wishlist' });
  }
});

export default router;
