import express from 'express';

const router = express.Router();

router.post('/', async (req, res) => {
  const { rental_id, issue } = req.body;
  const db = req.app.locals.db;
  try {
    const result = await db.run(
      'INSERT INTO maintenance_requests (rental_id, issue) VALUES (?, ?)',
      [rental_id, issue]
    );
    res.status(201).json({ id: result.lastID, message: 'Maintenance request submitted' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to submit request' });
  }
});

router.get('/rental/:rentalId', async (req, res) => {
  const db = req.app.locals.db;
  try {
    const requests = await db.all('SELECT * FROM maintenance_requests WHERE rental_id = ?', [req.params.rentalId]);
    res.json(requests);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch requests' });
  }
});

export default router;
