import { initDb } from './db.js';

async function seed() {
  const db = await initDb();

  // Clear existing products
  await db.run('DELETE FROM products');
  // Reset autoincrement
  await db.run('DELETE FROM sqlite_sequence WHERE name="products"');

  const products = [
    // Living Room
    {
      name: 'Luxury Velvet Sectional',
      category: 'Furniture',
      sub_category: 'Sofa',
      description: 'Handcrafted velvet sectional with gold-plated legs. Includes premium upholstery and high-density foam.',
      monthly_rent: 2400,
      security_deposit: 6000,
      stock: 12,
      image_url: 'https://images.unsplash.com/photo-1555041469-a586c61ea9bc?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Cloud Modular Sofa',
      category: 'Furniture',
      sub_category: 'Sofa',
      description: 'Ultra-comfortable modular sofa with breathable linen fabric. Perfect for modern living rooms.',
      monthly_rent: 1800,
      security_deposit: 4500,
      stock: 8,
      image_url: 'https://images.unsplash.com/photo-1493663284031-b7e3aefcae8e?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Marble Top Coffee Table',
      category: 'Furniture',
      sub_category: 'Table',
      description: 'Italian marble top with a minimalist black steel frame.',
      monthly_rent: 450,
      security_deposit: 1200,
      stock: 20,
      image_url: 'https://images.unsplash.com/photo-1533090161767-e6ffed986c88?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Mid-Century Oak TV Unit',
      category: 'Furniture',
      sub_category: 'Living Room',
      description: 'Solid oak wood TV stand with spacious storage and cable management.',
      monthly_rent: 650,
      security_deposit: 1500,
      stock: 10,
      image_url: 'https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&q=80&w=1000'
    },
    // Bedroom
    {
      name: 'King Size Teak Bed',
      category: 'Furniture',
      sub_category: 'Bed',
      description: 'Solid teak wood bed frame with an ergonomic headrest and orthopedic mattress.',
      monthly_rent: 1800,
      security_deposit: 4500,
      stock: 8,
      image_url: 'https://images.unsplash.com/photo-1505693419148-4030a90441c9?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Queen Size Velvet Bed',
      category: 'Furniture',
      sub_category: 'Bed',
      description: 'Luxurious velvet-upholstered bed frame with a button-tufted headboard.',
      monthly_rent: 1500,
      security_deposit: 3800,
      stock: 10,
      image_url: 'https://images.unsplash.com/photo-1560185007-cde436f6a4d0?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Smart Mirror Wardrobe',
      category: 'Furniture',
      sub_category: 'Wardrobe',
      description: 'Spacious 4-door wardrobe with built-in LED sensors and full-length mirrors.',
      monthly_rent: 1100,
      security_deposit: 3000,
      stock: 15,
      image_url: 'https://images.unsplash.com/photo-1595428774223-ef52624120d2?auto=format&fit=crop&q=80&w=1000'
    },
    // Kitchen/Appliances
    {
      name: 'Double Door Smart Fridge',
      category: 'Appliances',
      sub_category: 'Kitchen',
      description: '560L side-by-side refrigerator with touch-screen and internal cameras.',
      monthly_rent: 2800,
      security_deposit: 7000,
      stock: 5,
      image_url: 'https://images.unsplash.com/photo-1584622650111-993a426fbf0a?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Chef Grade Oven & Stove',
      category: 'Appliances',
      sub_category: 'Kitchen',
      description: 'Stainless steel 5-burner gas stove with a convection oven.',
      monthly_rent: 1500,
      security_deposit: 4000,
      stock: 10,
      image_url: 'https://images.unsplash.com/photo-1556911220-e15b29be8c8f?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Smart Dishwasher',
      category: 'Appliances',
      sub_category: 'Kitchen',
      description: 'High-efficiency dishwasher with multiple wash cycles and app control.',
      monthly_rent: 950,
      security_deposit: 2500,
      stock: 7,
      image_url: 'https://images.unsplash.com/photo-1585837553559-a0e4950912ad?auto=format&fit=crop&q=80&w=1000'
    },
    // Home Office
    {
      name: 'Ergonomic Executive Chair',
      category: 'Furniture',
      sub_category: 'Office',
      description: 'High-back mesh chair with lumbar support and 4D armrests.',
      monthly_rent: 750,
      security_deposit: 2000,
      stock: 25,
      image_url: 'https://images.unsplash.com/photo-1505797149-43b0069ec26b?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Standing Desk (Electric)',
      category: 'Furniture',
      sub_category: 'Office',
      description: 'Dual-motor standing desk with height memory presets.',
      monthly_rent: 900,
      security_deposit: 2500,
      stock: 18,
      image_url: 'https://images.unsplash.com/photo-1593062096033-9a26b09da705?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: 'Pro Gaming Chair',
      category: 'Furniture',
      sub_category: 'Office',
      description: 'Ergonomic racing-style chair with neck and lumbar pillows. Reclines up to 180 degrees.',
      monthly_rent: 650,
      security_deposit: 1800,
      stock: 12,
      image_url: 'https://images.unsplash.com/photo-1598550476439-6847785fce6c?auto=format&fit=crop&q=80&w=1000'
    },
    {
      name: '65" OLED Smart TV',
      category: 'Appliances',
      sub_category: 'Living Room',
      description: 'Ultra-thin OLED display with perfect blacks and infinite contrast. Built-in theater sound.',
      monthly_rent: 3200,
      security_deposit: 8000,
      stock: 5,
      image_url: 'https://images.unsplash.com/photo-1593359677879-a4bb92f829d1?auto=format&fit=crop&q=80&w=1000'
    },
    // Outdoor
    {
      name: 'Patio Lounge Set',
      category: 'Furniture',
      sub_category: 'Outdoor',
      description: 'Weather-resistant wicker sofa set with waterproof cushions.',
      monthly_rent: 1600,
      security_deposit: 4000,
      stock: 6,
      image_url: 'https://images.unsplash.com/photo-1620023471010-858888062534?auto=format&fit=crop&q=80&w=1000'
    }
  ];

  for (const p of products) {
    await db.run(
      'INSERT INTO products (name, category, sub_category, description, monthly_rent, security_deposit, stock, image_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [p.name, p.category, p.sub_category, p.description, p.monthly_rent, p.security_deposit, p.stock, p.image_url]
    );
  }

  console.log('Sample data seeded!');
  await db.close();
}

seed().catch(err => console.error(err));
