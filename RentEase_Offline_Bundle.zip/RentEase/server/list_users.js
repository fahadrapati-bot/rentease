import sqlite3 from 'sqlite3';
import { open } from 'sqlite';

async function listUsers() {
  const db = await open({
    filename: './database.sqlite',
    driver: sqlite3.Database
  });

  const users = await db.all('SELECT id, name, email, role FROM users');
  console.log('--- SIGNED UP USERS ---');
  console.table(users);
  await db.close();
}

listUsers().catch(err => console.error(err));
